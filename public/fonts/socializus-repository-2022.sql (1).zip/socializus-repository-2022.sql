-- phpMyAdmin SQL Dump
-- version 5.0.4deb2ubuntu5
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:3306
-- Généré le : lun. 28 fév. 2022 à 00:25
-- Version du serveur :  8.0.28-0ubuntu0.21.10.3
-- Version de PHP : 8.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `socializus-repository-2022`
--

-- --------------------------------------------------------

--
-- Structure de la table `categories`
--

CREATE TABLE `categories` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `categories`
--

INSERT INTO `categories` (`id`, `name`, `image`, `created_at`, `updated_at`) VALUES
(1, 'Activities', 'Activities.png', NULL, NULL),
(2, 'Afterwork', 'Afterwork.png', NULL, NULL),
(3, 'Apero', 'Apero.png', NULL, NULL),
(4, 'Cinema', 'Cinema.png', NULL, NULL),
(5, 'Culture', 'Culture.png', NULL, NULL),
(6, 'Dancing', 'Dancing.png', NULL, NULL),
(7, 'Game', 'Game.png', NULL, NULL),
(8, 'House Party', 'House-Party.png', NULL, NULL),
(9, 'Job', 'Job.png', '2022-02-23 09:51:23', '2022-02-23 09:51:23'),
(10, 'Linguistic', 'Linguistic.png', '2022-02-23 09:51:23', '2022-02-23 09:51:23'),
(11, 'Meal', 'Meal.png', '2022-02-23 09:52:03', '2022-02-23 09:52:03'),
(12, 'Music', 'Music.png', '2022-02-23 09:52:03', '2022-02-23 09:52:03'),
(13, 'Mutual Help', 'Mutual-Help.png', '2022-02-23 09:52:42', '2022-02-23 09:52:42'),
(14, 'Party', 'Party.png', '2022-02-23 09:52:42', '2022-02-23 09:52:42'),
(15, 'Picnic', 'Picnic.png', '2022-02-23 09:53:29', '2022-02-23 09:53:29'),
(16, 'Sport', 'Sport.png', '2022-02-23 09:53:29', '2022-02-23 09:53:29'),
(17, 'Travel', 'Travel.png', '2022-02-23 09:54:14', '2022-02-23 09:54:14');

-- --------------------------------------------------------

--
-- Structure de la table `ch_favorites`
--

CREATE TABLE `ch_favorites` (
  `id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `favorite_id` bigint NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `ch_messages`
--

CREATE TABLE `ch_messages` (
  `id` bigint NOT NULL,
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_id` bigint NOT NULL,
  `to_id` bigint NOT NULL,
  `body` varchar(5000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachment` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seen` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `comments`
--

CREATE TABLE `comments` (
  `id` bigint UNSIGNED NOT NULL,
  `comment_text` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_id` int NOT NULL,
  `user_id` int NOT NULL,
  `photo_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `reply_id` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `comments`
--

INSERT INTO `comments` (`id`, `comment_text`, `event_id`, `user_id`, `photo_url`, `video_url`, `location_url`, `created_at`, `updated_at`, `reply_id`) VALUES
(1, 'hello', 1, 2, '', '', NULL, '2022-01-17 16:33:12', '2022-01-17 16:33:12', 0),
(2, 'hedbkjds dcbiduhd  cdjhcbeoiuchecc cuihuiehcnewicluer ejbcieufchjbenwic eeirufcheriucjkbcieuc cbirbeirufjkcniuhr c ierfubhjerfn ieufrefr rhbviubfewifhewif erhbiewufhbewifubeiurenreeivhre9foih', 7, 1, '', '', NULL, '2022-01-18 16:33:35', '2022-01-18 16:33:35', 0),
(3, 'test 1 2 3', 3, 2, '', '', NULL, '2022-01-18 16:36:07', '2022-01-18 16:36:07', 0),
(4, 'yess i am here', 11, 8, '', '', NULL, '2022-01-18 17:00:18', '2022-01-18 17:00:18', 0),
(5, 'hellooo replieddd', 11, 8, '', '', NULL, '2022-01-18 17:00:27', '2022-01-18 17:00:27', 4),
(6, 'hedbkjds dcbiduhd  cdjhcbeoiuchecc cuihuiehcnewicluer ejbcieufchjbenwic eeirufcheriucjkbcieuc cbirbeirufjkcniuhr c ierfubhjerfn ieufrefr rhbviubfewifhewif erhbiewufhbewifubeiurenreeivhre9foih', 2, 8, '', '', NULL, '2022-01-18 17:01:35', '2022-01-18 17:01:35', 0),
(7, 'hello', 3, 3, '', '', NULL, '2022-01-18 20:35:58', '2022-01-18 20:35:58', 3),
(8, 'It\'s not possible to let a comment here because I do not attends', 22, 3, '', '', NULL, '2022-01-23 14:26:56', '2022-01-23 14:26:56', 0),
(9, 'yess i am here', 27, 18, '', '', NULL, '2022-01-25 18:28:17', '2022-01-25 18:28:17', 0),
(10, 'yess i read your comment jean', 1, 1, '', '', NULL, '2022-01-26 06:16:42', '2022-01-26 06:16:42', 0),
(11, '???', 28, 2, '', '', NULL, '2022-01-27 01:33:55', '2022-01-27 01:33:55', 0),
(12, 'I m not able to participate', 27, 2, '', '', NULL, '2022-01-27 01:37:23', '2022-01-27 01:37:23', 0),
(13, 'yes but impossible to unsubscribe', 26, 2, '', '', NULL, '2022-02-03 20:47:47', '2022-02-03 20:47:47', 0),
(16, 'Hello', 8, 28, '', '', NULL, '2022-02-25 15:41:02', '2022-02-25 15:41:02', 0),
(18, 'you are good', 8, 28, '', '', NULL, '2022-02-25 15:41:40', '2022-02-25 15:41:40', 0),
(19, 'Heyya', 8, 27, '', '', NULL, '2022-02-25 15:42:21', '2022-02-25 15:42:21', 0),
(20, 'They are good', 8, 27, '', '', NULL, '2022-02-25 15:42:30', '2022-02-25 15:42:30', 0),
(21, 'This is great', 8, 27, '', '', NULL, '2022-02-25 15:43:16', '2022-02-25 15:43:16', 0),
(22, 'Hello', 10, 27, '', '', NULL, '2022-02-25 15:56:10', '2022-02-25 15:56:10', 0),
(24, 'How are you ????', 10, 28, '', '', NULL, '2022-02-25 15:57:43', '2022-02-25 15:57:43', 0),
(25, 'bon ça à l\'air pas mal', 13, 37, '', '', NULL, '2022-02-27 17:53:35', '2022-02-27 17:53:35', 0),
(26, 'bon ça à l\'air pas mal 2', 13, 37, '', '', NULL, '2022-02-27 17:54:00', '2022-02-27 17:54:00', 0);

-- --------------------------------------------------------

--
-- Structure de la table `event_allowed_genders`
--

CREATE TABLE `event_allowed_genders` (
  `id` bigint UNSIGNED NOT NULL,
  `gender_id` int NOT NULL,
  `event_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `event_allowed_payment_methods`
--

CREATE TABLE `event_allowed_payment_methods` (
  `id` bigint UNSIGNED NOT NULL,
  `payment_method_id` int NOT NULL,
  `event_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `event_conditions`
--

CREATE TABLE `event_conditions` (
  `id` bigint UNSIGNED NOT NULL,
  `allowed_people` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `visible_phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `people_meeting` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `co_organizer` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `organise_event_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `event_conditions`
--

INSERT INTO `event_conditions` (`id`, `allowed_people`, `visible_phone`, `people_meeting`, `co_organizer`, `organise_event_id`, `created_at`, `updated_at`) VALUES
(1, '0', '0', '0', '0', 1, '2022-02-16 07:24:13', '2022-02-16 07:24:13'),
(2, '0', '0', '0', '0', 2, '2022-02-16 12:34:09', '2022-02-16 12:34:09'),
(3, '0', '0', '0', '0', 3, '2022-02-22 04:36:11', '2022-02-22 04:36:11'),
(4, '0', '0', '0', '0', 4, '2022-02-22 04:53:26', '2022-02-22 04:53:26'),
(5, '0', '0', '0', '0', 5, '2022-02-23 05:08:18', '2022-02-23 05:08:18'),
(11, '0', '0', '0', '0', 11, '2022-02-26 10:28:06', '2022-02-26 10:28:06'),
(12, '0', '0', '0', '0', 12, '2022-02-26 13:15:15', '2022-02-26 13:15:15'),
(13, '0', '0', '0', '0', 13, '2022-02-26 13:19:33', '2022-02-26 13:19:33'),
(14, '0', '0', '0', '0', 14, '2022-02-26 13:22:21', '2022-02-26 13:22:21'),
(15, '0', '0', '0', '0', 15, '2022-02-26 13:24:04', '2022-02-26 13:24:04'),
(17, '0', '0', '0', '0', 17, '2022-02-26 13:27:12', '2022-02-26 13:27:12'),
(18, '0', '0', '0', '0', 18, '2022-02-26 13:29:29', '2022-02-26 13:29:29'),
(19, '0', '0', '0', '0', 19, '2022-02-26 19:59:34', '2022-02-26 19:59:34'),
(20, '0', '0', '0', '0', 20, '2022-02-26 20:00:35', '2022-02-26 20:00:35'),
(21, '0', '0', '0', '0', 20, '2022-02-27 18:58:00', '2022-02-27 18:58:00'),
(22, '0', '0', '0', '0', 21, '2022-02-27 19:41:33', '2022-02-27 19:41:33'),
(23, '0', '0', '0', '0', 22, '2022-02-27 19:49:19', '2022-02-27 19:49:19'),
(24, '0', '0', '0', '0', 23, '2022-02-27 20:50:12', '2022-02-27 20:50:12'),
(25, '0', '0', '0', '0', 24, '2022-02-27 20:56:38', '2022-02-27 20:56:38'),
(26, '0', '0', '0', '0', 25, '2022-02-27 21:05:04', '2022-02-27 21:05:04');

-- --------------------------------------------------------

--
-- Structure de la table `event_images`
--

CREATE TABLE `event_images` (
  `id` bigint UNSIGNED NOT NULL,
  `event_id` int NOT NULL,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `event_images`
--

INSERT INTO `event_images` (`id`, `event_id`, `image`, `created_at`, `updated_at`) VALUES
(1, 11, 'events/2i8mlwQ0GeQjpwlYAigZbaRWnSIA8Ohdoxz0StLU.png', '2022-02-26 10:28:06', '2022-02-26 10:28:06'),
(2, 11, 'events/JZZjceJpYKCMWimYKg9GD7r5kY4pOwfbCxK06MCE.png', '2022-02-26 10:28:06', '2022-02-26 10:28:06'),
(3, 11, 'events/pdbr8pkP4rIRX6EzAbn09EiSwXRThMirHiusKUeD.png', '2022-02-26 10:28:06', '2022-02-26 10:28:06'),
(4, 11, 'events/CScj6rY8P0lBUiVre3vlSwe5jTkN0EiwrQmcKzt7.jpg', '2022-02-26 10:28:06', '2022-02-26 10:28:06'),
(5, 12, 'events/Hja99z7LmGiit0eRTbPnfLGN3GdcrmavVpU3NYCs.jpg', '2022-02-26 13:15:15', '2022-02-26 13:15:15'),
(6, 12, 'events/BEXL26POAwanA50q9et3im2JhaDKhjdAaQV7fCam.jpg', '2022-02-26 13:15:15', '2022-02-26 13:15:15'),
(7, 12, 'events/Cx3FDwGDakTtS2HVxdjFKZj4U3zaAzq53o3yswv9.jpg', '2022-02-26 13:15:15', '2022-02-26 13:15:15'),
(8, 13, 'events/x2JdhN0MRNt9e81lpKPxJw1dbaUG85vnhnUFw1B7.jpg', '2022-02-26 13:19:33', '2022-02-26 13:19:33'),
(9, 13, 'events/F7lumdF45a1vDqpZSlelFGGDtL7g38csYkA8xjaC.jpg', '2022-02-26 13:19:33', '2022-02-26 13:19:33'),
(10, 14, 'events/sJhYVC1kVH3u654DARoHb6HQzVhxz4JkSJYgCbmX.jpg', '2022-02-26 13:22:21', '2022-02-26 13:22:21'),
(11, 14, 'events/u5bIouoD5GObq775zOYJJfcerc332BjOeVmpuS6q.jpg', '2022-02-26 13:22:21', '2022-02-26 13:22:21'),
(12, 15, 'events/7Rs1FTPw7kPWeQHdXaqMmadfhyEAbU57Z1c0QJ90.jpg', '2022-02-26 13:24:04', '2022-02-26 13:24:04'),
(13, 15, 'events/IMmqLpNL4aFoGqhN5ikIIajQkS0pLAcAgc6UeuvY.jpg', '2022-02-26 13:24:04', '2022-02-26 13:24:04'),
(14, 18, 'events/lfHuPmhTY1bmNBNj7953GmQPQFU5jNvmvtydYuYc.jpg', '2022-02-26 13:29:29', '2022-02-26 13:29:29'),
(15, 18, 'events/HVLxrddccXz9XezuRUGfeRwzmsi9FK6VCq1ZLgVV.jpg', '2022-02-26 13:29:29', '2022-02-26 13:29:29'),
(16, 24, 'events/RAaJL3nuZ8oJveQuseGNXVGiBmb3kTVEKjY2Sy3c.png', '2022-02-27 20:56:38', '2022-02-27 20:56:38');

-- --------------------------------------------------------

--
-- Structure de la table `event_participents`
--

CREATE TABLE `event_participents` (
  `id` bigint UNSIGNED NOT NULL,
  `event_id` int NOT NULL,
  `user_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_approved` tinyint(1) NOT NULL DEFAULT '0',
  `is_organiser` int NOT NULL DEFAULT '0' COMMENT 'means co-organiser',
  `is_organiser_approved` int NOT NULL DEFAULT '0',
  `is_blacklisted` int NOT NULL DEFAULT '0',
  `friend_count` int NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `event_participents`
--

INSERT INTO `event_participents` (`id`, `event_id`, `user_id`, `created_at`, `updated_at`, `is_approved`, `is_organiser`, `is_organiser_approved`, `is_blacklisted`, `friend_count`) VALUES
(1, 1, 27, '2022-02-16 07:24:13', '2022-02-16 07:24:13', 1, 0, 0, 0, 1),
(2, 2, 27, '2022-02-16 12:34:09', '2022-02-16 12:34:09', 1, 0, 0, 0, 1),
(3, 3, 27, '2022-02-22 04:36:11', '2022-02-22 04:36:11', 1, 0, 0, 0, 1),
(4, 4, 27, '2022-02-22 04:53:26', '2022-02-22 04:53:26', 1, 0, 0, 0, 1),
(5, 5, 27, '2022-02-23 05:08:18', '2022-02-23 05:08:18', 1, 0, 0, 0, 1),
(6, 6, 27, '2022-02-24 12:49:09', '2022-02-24 12:49:09', 1, 0, 0, 0, 1),
(7, 7, 27, '2022-02-24 12:51:53', '2022-02-24 12:51:53', 1, 0, 0, 0, 1),
(8, 8, 27, '2022-02-24 12:53:33', '2022-02-24 12:53:33', 1, 0, 0, 0, 1),
(15, 9, 27, '2022-02-25 15:54:17', '2022-02-25 15:54:17', 1, 0, 0, 0, 1),
(16, 10, 27, '2022-02-25 15:55:47', '2022-02-25 15:55:47', 1, 1, 1, 0, 1),
(23, 10, 28, '2022-02-26 06:34:34', '2022-02-26 06:49:46', 0, 0, 0, 1, 1),
(24, 11, 27, '2022-02-26 10:28:06', '2022-02-26 10:28:06', 1, 1, 1, 0, 1),
(26, 12, 27, '2022-02-26 13:15:15', '2022-02-26 13:15:15', 1, 1, 1, 0, 1),
(27, 13, 27, '2022-02-26 13:19:33', '2022-02-26 13:19:33', 1, 1, 1, 0, 1),
(28, 14, 27, '2022-02-26 13:22:21', '2022-02-26 13:22:21', 1, 1, 1, 0, 1),
(29, 15, 27, '2022-02-26 13:24:04', '2022-02-26 13:24:04', 1, 1, 1, 0, 1),
(31, 17, 27, '2022-02-26 13:27:12', '2022-02-26 13:27:12', 1, 1, 1, 0, 1),
(32, 18, 27, '2022-02-26 13:29:29', '2022-02-26 13:29:29', 1, 1, 1, 0, 1),
(33, 19, 30, '2022-02-26 19:59:34', '2022-02-26 19:59:34', 1, 1, 1, 0, 1),
(34, 20, 30, '2022-02-26 20:00:35', '2022-02-26 20:00:35', 1, 1, 1, 0, 1),
(40, 13, 10, '2022-02-27 08:29:19', '2022-02-27 08:29:38', 1, 1, 0, 0, 1),
(41, 12, 10, '2022-02-27 08:32:27', '2022-02-27 08:32:27', 1, 0, 0, 0, 1),
(42, 11, 10, '2022-02-27 08:38:22', '2022-02-27 08:38:22', 0, 0, 0, 0, 1),
(43, 13, 37, '2022-02-27 17:52:44', '2022-02-27 17:52:59', 1, 1, 0, 0, 1),
(44, 20, 39, '2022-02-27 18:58:00', '2022-02-27 18:58:00', 1, 1, 1, 0, 1),
(45, 19, 39, '2022-02-27 18:58:34', '2022-02-27 18:58:53', 1, 1, 0, 0, 1),
(46, 21, 40, '2022-02-27 19:41:33', '2022-02-27 19:41:33', 1, 1, 1, 0, 1),
(47, 22, 40, '2022-02-27 19:49:19', '2022-02-27 19:49:19', 1, 1, 1, 0, 1),
(48, 23, 7, '2022-02-27 20:50:12', '2022-02-27 20:50:12', 1, 1, 1, 0, 6),
(49, 24, 7, '2022-02-27 20:56:38', '2022-02-27 20:56:38', 1, 1, 1, 0, 1),
(50, 25, 7, '2022-02-27 21:05:04', '2022-02-27 21:05:04', 1, 1, 1, 0, 1);

-- --------------------------------------------------------

--
-- Structure de la table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL,
  `uuid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `global_languages`
--

CREATE TABLE `global_languages` (
  `id` int NOT NULL,
  `code` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `nativeName` varchar(191) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `global_languages`
--

INSERT INTO `global_languages` (`id`, `code`, `name`, `nativeName`, `created_at`, `updated_at`) VALUES
(1, 'ab', 'Abkhaz', 'аҧсуа', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(2, 'aa', 'Afar', 'Afaraf', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(3, 'af', 'Afrikaans', 'Afrikaans', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(4, 'ak', 'Akan', 'Akan', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(5, 'sq', 'Albanian', 'Shqip', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(6, 'am', 'Amharic', 'አማርኛ', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(7, 'ar', 'Arabic', 'العربية', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(8, 'an', 'Aragonese', 'Aragonés', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(9, 'hy', 'Armenian', 'Հայերեն', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(10, 'as', 'Assamese', 'অসমীয়া', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(11, 'av', 'Avaric', 'авар мацӀ, магӀарул мацӀ', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(12, 'ae', 'Avestan', 'avesta', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(13, 'ay', 'Aymara', 'aymar aru', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(14, 'az', 'Azerbaijani', 'azərbaycan dili', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(15, 'bm', 'Bambara', 'bamanankan', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(16, 'ba', 'Bashkir', 'башҡорт теле', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(17, 'eu', 'Basque', 'euskara, euskera', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(18, 'be', 'Belarusian', 'Беларуская', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(19, 'bn', 'Bengali', 'বাংলা', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(20, 'bh', 'Bihari', 'भोजपुरी', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(21, 'bi', 'Bislama', 'Bislama', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(22, 'bs', 'Bosnian', 'bosanski jezik', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(23, 'br', 'Breton', 'brezhoneg', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(24, 'bg', 'Bulgarian', 'български език', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(25, 'my', 'Burmese', 'ဗမာစာ', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(26, 'ca', 'Catalan; Valencian', 'Català', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(27, 'ch', 'Chamorro', 'Chamoru', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(28, 'ce', 'Chechen', 'нохчийн мотт', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(29, 'ny', 'Chichewa; Chewa; Nyanja', 'chiCheŵa, chinyanja', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(30, 'zh', 'Chinese', '中文 (Zhōngwén), 汉语, 漢語', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(31, 'cv', 'Chuvash', 'чӑваш чӗлхи', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(32, 'kw', 'Cornish', 'Kernewek', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(33, 'co', 'Corsican', 'corsu, lingua corsa', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(34, 'cr', 'Cree', 'ᓀᐦᐃᔭᐍᐏᐣ', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(35, 'hr', 'Croatian', 'hrvatski', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(36, 'cs', 'Czech', 'česky, čeština', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(37, 'da', 'Danish', 'dansk', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(38, 'dv', 'Divehi; Dhivehi; Maldivian;', 'ދިވެހި', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(39, 'nl', 'Dutch', 'Nederlands, Vlaams', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(40, 'en', 'English', 'English', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(41, 'eo', 'Esperanto', 'Esperanto', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(42, 'et', 'Estonian', 'eesti, eesti keel', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(43, 'ee', 'Ewe', 'Eʋegbe', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(44, 'fo', 'Faroese', 'føroyskt', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(45, 'fj', 'Fijian', 'vosa Vakaviti', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(46, 'fi', 'Finnish', 'suomi, suomen kieli', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(47, 'fr', 'French', 'français, langue française', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(48, 'ff', 'Fula; Fulah; Pulaar; Pular', 'Fulfulde, Pulaar, Pular', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(49, 'gl', 'Galician', 'Galego', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(50, 'ka', 'Georgian', 'ქართული', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(51, 'de', 'German', 'Deutsch', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(52, 'el', 'Greek, Modern', 'Ελληνικά', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(53, 'gn', 'Guaraní', 'Avañeẽ', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(54, 'gu', 'Gujarati', 'ગુજરાતી', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(55, 'ht', 'Haitian; Haitian Creole', 'Kreyòl ayisyen', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(56, 'ha', 'Hausa', 'Hausa, هَوُسَ', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(57, 'he', 'Hebrew (modern)', 'עברית', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(58, 'hz', 'Herero', 'Otjiherero', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(59, 'hi', 'Hindi', 'हिन्दी, हिंदी', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(60, 'ho', 'Hiri Motu', 'Hiri Motu', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(61, 'hu', 'Hungarian', 'Magyar', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(62, 'ia', 'Interlingua', 'Interlingua', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(63, 'id', 'Indonesian', 'Bahasa Indonesia', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(64, 'ie', 'Interlingue', 'Originally called Occidental; then Interlingue after WWII', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(65, 'ga', 'Irish', 'Gaeilge', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(66, 'ig', 'Igbo', 'Asụsụ Igbo', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(67, 'ik', 'Inupiaq', 'Iñupiaq, Iñupiatun', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(68, 'io', 'Ido', 'Ido', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(69, 'is', 'Icelandic', 'Íslenska', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(70, 'it', 'Italian', 'Italiano', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(71, 'iu', 'Inuktitut', 'ᐃᓄᒃᑎᑐᑦ', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(72, 'ja', 'Japanese', '日本語 (にほんご／にっぽんご)', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(73, 'jv', 'Javanese', 'basa Jawa', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(74, 'kl', 'Kalaallisut, Greenlandic', 'kalaallisut, kalaallit oqaasii', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(75, 'kn', 'Kannada', 'ಕನ್ನಡ', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(76, 'kr', 'Kanuri', 'Kanuri', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(77, 'ks', 'Kashmiri', 'कश्मीरी, كشميري‎', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(78, 'kk', 'Kazakh', 'Қазақ тілі', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(79, 'km', 'Khmer', 'ភាសាខ្មែរ', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(80, 'ki', 'Kikuyu, Gikuyu', 'Gĩkũyũ', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(81, 'rw', 'Kinyarwanda', 'Ikinyarwanda', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(82, 'ky', 'Kirghiz, Kyrgyz', 'кыргыз тили', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(83, 'kv', 'Komi', 'коми кыв', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(84, 'kg', 'Kongo', 'KiKongo', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(85, 'ko', 'Korean', '한국어 (韓國語), 조선말 (朝鮮語)', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(86, 'ku', 'Kurdish', 'Kurdî, كوردی‎', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(87, 'kj', 'Kwanyama, Kuanyama', 'Kuanyama', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(88, 'la', 'Latin', 'latine, lingua latina', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(89, 'lb', 'Luxembourgish, Letzeburgesch', 'Lëtzebuergesch', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(90, 'lg', 'Luganda', 'Luganda', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(91, 'li', 'Limburgish, Limburgan, Limburger', 'Limburgs', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(92, 'ln', 'Lingala', 'Lingála', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(93, 'lo', 'Lao', 'ພາສາລາວ', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(94, 'lt', 'Lithuanian', 'lietuvių kalba', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(95, 'lu', 'Luba-Katanga', '', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(96, 'lv', 'Latvian', 'latviešu valoda', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(97, 'gv', 'Manx', 'Gaelg, Gailck', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(98, 'mk', 'Macedonian', 'македонски јазик', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(99, 'mg', 'Malagasy', 'Malagasy fiteny', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(100, 'ms', 'Malay', 'bahasa Melayu, بهاس ملايو‎', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(101, 'ml', 'Malayalam', 'മലയാളം', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(102, 'mt', 'Maltese', 'Malti', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(103, 'mi', 'Māori', 'te reo Māori', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(104, 'mr', 'Marathi (Marāṭhī)', 'मराठी', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(105, 'mh', 'Marshallese', 'Kajin M̧ajeļ', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(106, 'mn', 'Mongolian', 'монгол', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(107, 'na', 'Nauru', 'Ekakairũ Naoero', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(108, 'nv', 'Navajo, Navaho', 'Diné bizaad, Dinékʼehǰí', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(109, 'nb', 'Norwegian Bokmål', 'Norsk bokmål', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(110, 'nd', 'North Ndebele', 'isiNdebele', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(111, 'ne', 'Nepali', 'नेपाली', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(112, 'ng', 'Ndonga', 'Owambo', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(113, 'nn', 'Norwegian Nynorsk', 'Norsk nynorsk', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(114, 'no', 'Norwegian', 'Norsk', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(115, 'ii', 'Nuosu', 'ꆈꌠ꒿ Nuosuhxop', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(116, 'nr', 'South Ndebele', 'isiNdebele', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(117, 'oc', 'Occitan', 'Occitan', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(118, 'oj', 'Ojibwe, Ojibwa', 'ᐊᓂᔑᓈᐯᒧᐎᓐ', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(119, 'cu', 'Old Church Slavonic, Church Slavic, Church Slavonic, Old Bulgarian, Old Slavonic', 'ѩзыкъ словѣньскъ', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(120, 'om', 'Oromo', 'Afaan Oromoo', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(121, 'or', 'Oriya', 'ଓଡ଼ିଆ', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(122, 'os', 'Ossetian, Ossetic', 'ирон æвзаг', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(123, 'pa', 'Panjabi, Punjabi', 'ਪੰਜਾਬੀ, پنجابی‎', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(124, 'pi', 'Pāli', 'पाऴि', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(125, 'fa', 'Persian', 'فارسی', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(126, 'pl', 'Polish', 'polski', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(127, 'ps', 'Pashto, Pushto', 'پښتو', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(128, 'pt', 'Portuguese', 'Português', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(129, 'qu', 'Quechua', 'Runa Simi, Kichwa', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(130, 'rm', 'Romansh', 'rumantsch grischun', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(131, 'rn', 'Kirundi', 'kiRundi', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(132, 'ro', 'Romanian, Moldavian, Moldovan', 'română', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(133, 'ru', 'Russian', 'русский язык', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(134, 'sa', 'Sanskrit (Saṁskṛta)', 'संस्कृतम्', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(135, 'sc', 'Sardinian', 'sardu', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(136, 'sd', 'Sindhi', 'सिन्धी, سنڌي، سندھی‎', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(137, 'se', 'Northern Sami', 'Davvisámegiella', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(138, 'sm', 'Samoan', 'gagana faa Samoa', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(139, 'sg', 'Sango', 'yângâ tî sängö', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(140, 'sr', 'Serbian', 'српски језик', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(141, 'gd', 'Scottish Gaelic; Gaelic', 'Gàidhlig', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(142, 'sn', 'Shona', 'chiShona', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(143, 'si', 'Sinhala, Sinhalese', 'සිංහල', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(144, 'sk', 'Slovak', 'slovenčina', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(145, 'sl', 'Slovene', 'slovenščina', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(146, 'so', 'Somali', 'Soomaaliga, af Soomaali', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(147, 'st', 'Southern Sotho', 'Sesotho', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(148, 'es', 'Spanish; Castilian', 'español, castellano', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(149, 'su', 'Sundanese', 'Basa Sunda', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(150, 'sw', 'Swahili', 'Kiswahili', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(151, 'ss', 'Swati', 'SiSwati', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(152, 'sv', 'Swedish', 'svenska', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(153, 'ta', 'Tamil', 'தமிழ்', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(154, 'te', 'Telugu', 'తెలుగు', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(155, 'tg', 'Tajik', 'тоҷикӣ, toğikī, تاجیکی‎', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(156, 'th', 'Thai', 'ไทย', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(157, 'ti', 'Tigrinya', 'ትግርኛ', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(158, 'bo', 'Tibetan Standard, Tibetan, Central', 'བོད་ཡིག', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(159, 'tk', 'Turkmen', 'Türkmen, Түркмен', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(160, 'tl', 'Tagalog', 'Wikang Tagalog, ᜏᜒᜃᜅ᜔ ᜆᜄᜎᜓᜄ᜔', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(161, 'tn', 'Tswana', 'Setswana', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(162, 'to', 'Tonga (Tonga Islands)', 'faka Tonga', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(163, 'tr', 'Turkish', 'Türkçe', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(164, 'ts', 'Tsonga', 'Xitsonga', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(165, 'tt', 'Tatar', 'татарча, tatarça, تاتارچا‎', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(166, 'tw', 'Twi', 'Twi', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(167, 'ty', 'Tahitian', 'Reo Tahiti', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(168, 'ug', 'Uighur, Uyghur', 'Uyƣurqə, ئۇيغۇرچە‎', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(169, 'uk', 'Ukrainian', 'українська', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(170, 'ur', 'Urdu', 'اردو', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(171, 'uz', 'Uzbek', 'zbek, Ўзбек, أۇزبېك‎', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(172, 've', 'Venda', 'Tshivenḓa', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(173, 'vi', 'Vietnamese', 'Tiếng Việt', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(174, 'vo', 'Volapük', 'Volapük', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(175, 'wa', 'Walloon', 'Walon', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(176, 'cy', 'Welsh', 'Cymraeg', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(177, 'wo', 'Wolof', 'Wollof', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(178, 'fy', 'Western Frisian', 'Frysk', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(179, 'xh', 'Xhosa', 'isiXhosa', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(180, 'yi', 'Yiddish', 'ייִדיש', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(181, 'yo', 'Yoruba', 'Yorùbá', '2022-02-26 15:42:18', '2022-02-26 15:42:18'),
(182, 'za', 'Zhuang, Chuang', 'Saɯ cueŋƅ, Saw cuengh', '2022-02-26 15:42:18', '2022-02-26 15:42:18');

-- --------------------------------------------------------

--
-- Structure de la table `intrests`
--

CREATE TABLE `intrests` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `languages`
--

CREATE TABLE `languages` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `migrations`
--

CREATE TABLE `migrations` (
  `id` int UNSIGNED NOT NULL,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(50, '2014_10_11_000000_create_users_table', 1),
(51, '2014_10_12_100000_create_password_resets_table', 1),
(52, '2019_08_19_000000_create_failed_jobs_table', 1),
(53, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(54, '2021_12_14_180339_create_categories_table', 1),
(55, '2021_12_15_180339_create_organise_event_table', 1),
(56, '2021_12_15_182819_create_event_allowed_genders_table', 1),
(57, '2021_12_15_182845_create_event_allowed_payment_methods_table', 1),
(58, '2021_12_18_150509_create_comments_table', 1),
(59, '2021_12_18_181142_create_event_participents_table', 1),
(60, '2021_12_22_180507_add_field_to_comment_table', 1),
(61, '2021_12_24_192816_create_ch_messages_table', 1),
(62, '2021_12_24_200655_add_active_status_field_to_user_table', 1),
(63, '2021_12_24_201917_create_ch_favorites_table', 1),
(64, '2022_01_09_062334_add_socials_to_users_table', 1),
(65, '2022_01_16_091141_create_event_conditions_table', 1),
(66, '2022_01_17_175347_add_approved_status_to_event_participents_table', 2),
(67, '2022_01_20_063513_change_type_to_organise_events', 3),
(68, '2022_01_20_194100_create_languages_table', 4),
(69, '2022_01_20_194359_add_columns_to_users_table', 4),
(70, '2022_01_21_200734_add_time_to_organise_events_table', 4),
(71, '2022_01_25_193005_add_roles_to_users_table', 5),
(72, '2022_01_26_154210_create_user_images_table', 5),
(73, '2022_01_26_154413_create_intrests_table', 5),
(74, '2022_01_26_155048_create_roles_table', 5),
(75, '2022_01_26_192921_add_column_to_organise_events_table', 5),
(76, '2022_01_31_202938_add_duration_to_organise_events_table', 6),
(77, '2022_02_01_155241_add_field_to_user_table', 6);

-- --------------------------------------------------------

--
-- Structure de la table `organise_events`
--

CREATE TABLE `organise_events` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `category_id` bigint UNSIGNED NOT NULL,
  `event_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_type` int NOT NULL DEFAULT '0' COMMENT '0 => address, 1 => online, 2 => googleMapUrl',
  `event_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_country` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_pincode` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_city` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_state` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_lat` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_lng` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_start_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `find_us_description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_type` int NOT NULL DEFAULT '0' COMMENT '0 => free, 1 => paid,',
  `payable_type` int NOT NULL DEFAULT '0' COMMENT '0 => online, 1 => offline,',
  `no_of_participent` int DEFAULT NULL,
  `event_min_age` int DEFAULT NULL,
  `event_max_age` int DEFAULT NULL,
  `event_url` int DEFAULT NULL,
  `event_amount` int DEFAULT NULL,
  `address_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_date` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_start_time` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_duration` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_end_time` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unlimited_participants` int DEFAULT '0',
  `attendee_limitation` int DEFAULT '0',
  `no_price` int DEFAULT '0',
  `price_type` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `manage_restrictions` int DEFAULT '0',
  `friends_with_me` int DEFAULT '0',
  `allow_guest` int DEFAULT '0',
  `attributes` int DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `event_time` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `duration` int DEFAULT NULL,
  `attendee_limitation_for_premium` int DEFAULT NULL,
  `repeat_event` int DEFAULT NULL,
  `repeat_cycle` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `repeat_day` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `repeat_end_date` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `partity_male` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `allow_people_co_organiser` int DEFAULT NULL,
  `info_line` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Buy_Tickets_Link` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other_social` int DEFAULT NULL,
  `whatsapp_link` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `facebook_link` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `page_link` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meet_link` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telegram_link` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `manage_parity` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `organise_events`
--

INSERT INTO `organise_events` (`id`, `user_id`, `category_id`, `event_name`, `event_phone`, `event_type`, `event_address`, `event_country`, `event_pincode`, `event_city`, `event_state`, `event_lat`, `event_lng`, `event_start_date`, `image`, `event_description`, `find_us_description`, `payment_type`, `payable_type`, `no_of_participent`, `event_min_age`, `event_max_age`, `event_url`, `event_amount`, `address_type`, `event_date`, `event_start_time`, `event_duration`, `event_end_time`, `unlimited_participants`, `attendee_limitation`, `no_price`, `price_type`, `price`, `manage_restrictions`, `friends_with_me`, `allow_guest`, `attributes`, `created_at`, `updated_at`, `event_time`, `duration`, `attendee_limitation_for_premium`, `repeat_event`, `repeat_cycle`, `repeat_day`, `repeat_end_date`, `partity_male`, `allow_people_co_organiser`, `info_line`, `Buy_Tickets_Link`, `other_social`, `whatsapp_link`, `facebook_link`, `page_link`, `meet_link`, `telegram_link`, `manage_parity`) VALUES
(11, 27, 5, 'New York Texas Eve', NULL, 0, 'Texas City, TX, USA', 'United States', '77590', 'Galveston County', 'Texas', '29.383845', '-94.9027002', '2022-02-26 15:58:06', 'events/defaultevent.png', 'Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one ', 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour', 0, 0, NULL, NULL, NULL, NULL, NULL, 'address', '02/25/2022', '12:00', '3:00', '15:00', NULL, 1, 0, 'Onsite', '3300', NULL, 0, 0, 1, '2022-02-26 10:28:06', '2022-02-26 12:43:37', NULL, 0, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 0),
(12, 27, 12, 'Paris Fest 2022', NULL, 0, 'Paris, France', 'France', '75004', 'Département de Paris', 'Île-de-France', '48.856614', '2.3522219', '2022-02-26 18:45:15', 'events/defaultevent.png', 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, yo', 'The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from \"de Finibus Bonorum et Malorum\" by Cicero are also reproduced in their exact original form, accompanied by English versions ', 0, 0, NULL, NULL, NULL, NULL, NULL, 'address', '03/09/2022', '15:00', '8:30', '23:30', NULL, 8, 0, 'Online', '300', 0, 0, 0, 4, '2022-02-26 13:15:15', '2022-02-26 13:15:15', NULL, 0, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 0),
(13, 27, 6, 'Marseille Fest 22', NULL, 0, 'Marseille, France', 'France', '13002', 'Bouches-du-Rhône', 'Provence-Alpes-Côte d\'Azur', '43.296482', '5.36978', '2022-02-26 18:49:33', 'events/defaultevent.png', 'Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one ', 'Newspaper', 0, 0, NULL, NULL, NULL, NULL, NULL, 'address', '03/08/2022', '17:15', '2:00', '19:15', NULL, 15, 0, 'Online', '5500', 0, 0, 0, 1, '2022-02-26 13:19:33', '2022-02-26 13:19:33', NULL, 0, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 0),
(14, 27, 8, 'Lyon Festival France 2022 ---- ✓✓✓✓✓✓', NULL, 0, 'lyon france, Lyon, France', 'France', '69002', 'Rhône', 'Auvergne-Rhône-Alpes', '45.764043', '4.835659', '2022-02-26 18:52:21', 'events/defaultevent.png', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, co', 'Internet', 0, 0, NULL, NULL, NULL, NULL, NULL, 'address', '03/12/2022', '13:00', '3:00', '16:00', NULL, 9, 0, 'Online', '22000', 0, 0, 0, 1, '2022-02-26 13:22:21', '2022-02-26 13:22:21', NULL, 0, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 0),
(15, 27, 1, 'Bordeaux Main Square Festival', NULL, 0, 'Bordeaux, France', 'France', '33000', 'Gironde', 'Nouvelle-Aquitaine', '44.837789', '-0.57918', '2022-02-26 18:54:04', 'events/defaultevent.png', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has su', 'Translations: Can you help translate this site into a foreign language ? Please email us with details if you can help.', 0, 0, NULL, NULL, NULL, NULL, NULL, 'address', '03/16/2022', '16:00', '3:00', '19:00', NULL, 15, 0, 'Onsite', '1000', 0, 0, 0, 2, '2022-02-26 13:24:04', '2022-02-26 13:24:04', NULL, 0, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 0),
(17, 27, 7, 'Camping We Love Green -- 22/03/2022', NULL, 0, 'Toulouse, France', 'France', '31140', 'Haute-Garonne', 'Occitanie', '43.604652', '1.444209', '2022-02-26 18:57:12', 'events/defaultevent.png', 'The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from \"de Finibus Bonorum et Malorum\" by Cicero are also reproduced in their exact original form, accompanied by English versions ', 'by Cicero are also reproduced', 0, 0, NULL, NULL, NULL, NULL, NULL, 'address', '03/22/2022', '12:00', '6:00', '18:00', NULL, 15, NULL, 'Online', NULL, 0, 0, 0, 2, '2022-02-26 13:27:12', '2022-02-26 13:27:12', NULL, 0, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 0),
(18, 27, 6, 'Montpellier Music Love Festival - 22', NULL, 0, 'Montpellier, France', 'France', '34000', 'Hérault', 'Occitanie', '43.610769', '3.876716', '2022-02-26 18:59:29', 'events/defaultevent.png', 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, yo', 'The generated Lorem Ipsum is therefore always free from repetition', 0, 0, NULL, NULL, NULL, NULL, NULL, 'address', '03/30/2022', '12:00', '6:45', '18:45', NULL, 15, NULL, 'Online', NULL, 0, 0, 0, 2, '2022-02-26 13:29:29', '2022-02-26 13:29:29', NULL, 0, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 0),
(19, 27, 4, 'Rebase Music Launch Paris', NULL, 0, 'Paris Las Vegas, South Las Vegas Boulevard, Las Vegas, NV, USA', 'United States', '89109', 'Clark County', 'Nevada', '36.1125414', '-115.1706705', '2022-02-27 12:06:04', 'events/defaultevent.png', 'aDS', 'DDD', 0, 0, NULL, NULL, NULL, NULL, NULL, 'address', '03/10/2022', '12:00', '3:00', '15:00', NULL, 15, NULL, 'Online', NULL, NULL, 0, 0, 0, '2022-02-27 06:36:04', '2022-02-27 06:36:04', NULL, 0, 20, 0, 'Weekly', 'Monday', '02/28/2022', '44', 0, 'DAD', 'ASA', 0, 'GOOGLE.COM', 'GOOGLE.COM', 'GOOGLE.COM', 'GOOGLE.COM', 'GOOGLE.COM', 0),
(20, 39, 4, 'dsdfsfdfds', NULL, 0, 'The Dubai Mall - Dubaï - Émirats arabes unis', 'دبي', 'Émirats arabes unis', 'دبي', 'وسط مدينة دبي', '25.198765', '55.27960530000001', '2022-02-27 18:58:00', 'events/defaultevent.png', 'bvbvvbcbcvbcvbcvbcvbcvcvb', 'bvcvcbvvbcbvbvbvbvbvbv', 0, 0, NULL, NULL, NULL, NULL, NULL, 'address', '03/12/2022', '12:00', '3:00', '15:00', 1, 15, 0, 'Online', '10', 0, 0, 0, 0, '2022-02-27 18:58:00', '2022-02-27 18:58:00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(21, 40, 7, 'GFKJHFGDKHJFGD', NULL, 0, 'GF FAÑABÉ, Avenida de Bruselas, Costa Adeje, Spain', 'Spain', '38660', 'Santa Cruz de Tenerife', 'Canarias', '28.09040379999999', '-16.7354986', '2022-02-27 19:41:33', 'events/defaultevent.png', 'GFDDFGDFGGFDGFDGDFSDFG', 'GFDGDFDGGDFGDFGFD', 0, 0, NULL, NULL, NULL, NULL, NULL, 'address', '03/12/2022', '12:00', '3:00', '15:00', NULL, 15, NULL, 'Online', NULL, 0, 0, 0, 0, '2022-02-27 19:41:33', '2022-02-27 19:41:33', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(22, 40, 2, 'jhjhjhjhffjh', NULL, 0, 'Fusionopolis Place, Hgfg، Singapore', 'Singapore', 'Singapore', 'One-North Stn/Galaxis', 'Queenstown', '1.3001663', '103.7886488', '2022-02-27 19:49:19', 'events/defaultevent.png', 'jhjhghghjghj', 'jhgfjjhgjhg', 0, 0, NULL, NULL, NULL, NULL, NULL, 'address', '03/12/2022', '12:00', '3:00', '15:00', NULL, 15, NULL, 'Online', NULL, 0, 0, 0, 0, '2022-02-27 19:49:19', '2022-02-27 19:49:19', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(23, 7, 9, 'Afterwork with internationals - Ⓜ️ Bastille', NULL, 0, 'Pinkas Street 11, Tel-Aviv, Israël', 'Tel Aviv District', 'Israël', 'Pinkas Street', 'Tel Aviv-Yafo', '32.0910307', '34.7845555', '2022-02-27 20:50:12', 'events/defaultevent.png', 'nbvbnvbvbvnvbn', 'bvbvcxxcbbcvxvbxc', 0, 0, NULL, 18, 99, NULL, NULL, 'address', '03/12/2022', '7:15', '8:00', '15:00', NULL, 15, NULL, 'Online', NULL, 0, 5, 0, 0, '2022-02-27 20:50:12', '2022-02-27 20:50:12', NULL, NULL, 20, 0, 'Weekly', 'Wednesday', '31/03/2022', NULL, 0, 'bvcvbcbvc', 'bvcbvcbvcbvc', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(24, 7, 4, 'Afterwork with internationals - Ⓜ️ Bastille', NULL, 0, 'Pinkas Street 11, Tel-Aviv, Israël', 'Tel Aviv District', 'Israël', 'Pinkas Street', 'Tel Aviv-Yafo', '32.0910307', '34.7845555', '2022-02-27 20:56:38', 'events/defaultevent.png', 'fbbbbvbcvcbvbxcvbvbcvbc', 'bvcxvbbvbvc', 0, 0, NULL, NULL, NULL, NULL, NULL, 'address', '03/12/2022', '0:30', '1:30', '15:00', NULL, 15, NULL, 'Online', NULL, NULL, 0, 0, 0, '2022-02-27 20:56:38', '2022-02-27 20:56:38', NULL, NULL, 20, 0, 'Weekly', 'Monday', '30/04/2022', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(25, 7, 9, 'Afterwork with internationals - Ⓜ️ Bastille', NULL, 0, 'Via Giuseppe Mazzini, 20, Milan, Italie', 'Italie', '20123', 'Città Metropolitana di Milano', 'Lombardia', '45.4617212', '9.1884015', '2022-02-27 21:05:04', 'events/defaultevent.png', 'fgdhfdgfgddffdgfgd gfdfdfggfd', 'gfdgfgffgfggd. gfdfgdfgfdgdfg', 0, 0, NULL, NULL, NULL, NULL, NULL, 'address', '03/12/2022', '19:45', '3:00', '15:00', NULL, 15, NULL, 'Online', NULL, NULL, 0, 0, 0, '2022-02-27 21:05:04', '2022-02-27 21:05:04', NULL, NULL, 20, 0, 'Weekly', 'Monday', '31/03/2022', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `password_resets`
--

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('joe008@yopmail.com', 'zl0bV9ILt6X6ZdP4Vzw4gY7sVRwxdMcN2H5VpxLMMnwvODcfyCdKjQ5fJ8yE', '2022-02-11 15:35:00'),
('joe008@yopmail.com', 'r7ncz7RZlbiTEaqOfLI3ZeeI3eUW7JWUuJGaU5KWBBDvr0rYpiiXe5DVKY9c', '2022-02-11 15:37:17'),
('joe008@yopmail.com', 'xslwbm0wg9NRMXQpkvkzkBSxv4Z4Gibc3Jt03YxE6TgS9151jTjsGtThjDGE', '2022-02-11 15:37:28'),
('joe008@yopmail.com', 'Xm7BfVSO0vp8WOsC4Wb5enWCxgohFa5ifmh29BPtoZt5SRJYLxoEQ0MUYV1w', '2022-02-11 15:37:48'),
('joe008@yopmail.com', 'uah16y78WxNe9gTbBHPaaxfVQss8VLXqG1TAn2WW9faGAuSIA7eIRE59pOWb', '2022-02-11 15:38:46'),
('joe008@yopmail.com', 'CSTPsEUALCiH1IsF2T0QuiKMoXJkJqXqYRzbKnOKCNrhpaFdN01dhejbMLnO', '2022-02-11 15:39:38'),
('joe008@yopmail.com', 'Ii8gYyaUmJyBLnTPAsyLLBWPG7aq31S9QQZ1e7UO7el1gSAkl3GBdjLTyKgO', '2022-02-11 15:40:48'),
('joe008@yopmail.com', 'Nz6IZCuLnzhdi0fSprepjGsplfXiyBktuREbnmhhD5duQ9feM3gg40JpQ0pM', '2022-02-11 15:41:01'),
('joe008@yopmail.com', 'EPihcc1XHxQgDpipaWaHAQWZlVYwi5p6WRrOh4ynkIQIFNnEZaGh5PxyaKtC', '2022-02-11 15:41:45'),
('joe008@yopmail.com', 'bQ2eyyPw7IGMocuZyeWB3M035G48gUdz3xpir8Sy2gfEqaxXsdjbADP52Qq6', '2022-02-11 15:43:08');

-- --------------------------------------------------------

--
-- Structure de la table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `roles`
--

CREATE TABLE `roles` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `active_status` tinyint(1) NOT NULL DEFAULT '0',
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'avatar.png',
  `messenger_color` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '#2180f3',
  `dark_mode` tinyint(1) NOT NULL DEFAULT '0',
  `bio` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `provider` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `language` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'French',
  `dob` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_number` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` tinyint NOT NULL,
  `accountType` int NOT NULL DEFAULT '1',
  `accountName` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `spoken_language` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `undertaking` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `aboutus` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interest` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `children` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tobacco` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alcohol` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_profile_updated` int NOT NULL DEFAULT '0',
  `membership_number` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `active_status`, `avatar`, `messenger_color`, `dark_mode`, `bio`, `provider`, `provider_id`, `first_name`, `last_name`, `city`, `gender`, `language`, `dob`, `phone_number`, `role`, `accountType`, `accountName`, `spoken_language`, `undertaking`, `aboutus`, `interest`, `children`, `tobacco`, `alcohol`, `is_profile_updated`, `membership_number`) VALUES
(1, 'sabir', 'sabirshahbzu@gmail.com', '2022-01-17 20:59:57', '$2y$10$t2TDLTDRMVlO8q26nwI0COBmn5TGfHna6vS0GyGLWXAY2NR55Za5W', NULL, '2022-01-17 15:59:38', '2022-01-18 21:01:54', 1, 'avatar.png', '#2180f3', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL),
(2, '-team socializus', 'team@socializus.net', '2022-01-17 16:31:26', NULL, NULL, '2022-01-17 16:31:26', '2022-02-03 20:46:29', 1, 'avatar.png', '#2180f3', 0, NULL, 'google', '114864921526672286232', 'Ted', 'Team', 'Paris', 'Male', 'French', '2022-02-02', NULL, 0, 1, '1', '[\"france\",\"greek\",\"hungary\"]', '[\"email\"]', NULL, '[\"Buisness\"]', NULL, NULL, 'null', 0, NULL),
(3, 'Jean', 'jean@socializus.net', '2022-01-17 20:43:34', '$2y$10$78.XpQQc23uUEatgIZg8F.Vm.HORv.GqHEZwlbrbC18Q7xZpE3MH6', NULL, '2022-01-17 20:34:05', '2022-02-02 13:07:01', 1, 'avatar.png', '#2180f3', 0, NULL, NULL, NULL, 'Jean', 'Socializus', 'Paris', 'Male', 'French', '2022-02-01', NULL, 0, 1, '1', '[\"france\",\"spain\"]', '[\"email\",\"last_name\",\"phone_number\",\"dob\",\"membershipnumber\"]', NULL, '[\"Apero\",\"Buisness\",\"Culture\"]', 'No', 'Never', 'null', 0, NULL),
(4, 'Franco Gomes', 'cyancallum12@gmail.com', '2022-01-17 21:57:53', NULL, NULL, '2022-01-17 21:57:53', '2022-01-17 21:57:54', 1, 'avatar.png', '#2180f3', 0, NULL, 'facebook', '1434190756983386', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL),
(5, 'khalid shahzad', 'khalidbscs42@gmail.com', '2022-01-18 14:55:18', NULL, NULL, '2022-01-18 14:55:18', '2022-01-18 14:55:18', 1, 'avatar.png', '#2180f3', 0, NULL, 'google', '115847179848578894285', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL),
(6, 'sabi shah', 'sabirbscs05@gmail.com', '2022-01-18 14:59:05', NULL, NULL, '2022-01-18 14:59:05', '2022-01-18 14:59:06', 1, 'avatar.png', '#2180f3', 0, NULL, 'google', '102559550796638919393', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL),
(7, 'Paul', 'paul.f.gama@gmail.com', '2022-01-18 16:38:07', NULL, NULL, '2022-01-18 16:38:07', '2022-02-27 10:56:42', 1, 'users-avatar/9MlcFGrdazARsPYBpEJddcHQNodAC0XNXZCaUwcf.jpg', '#2180f3', 0, NULL, 'facebook', '3631781010294450', 'Paul', 'De Gama', 'Paris, France', 'Male', 'French', NULL, NULL, 0, 1, 'Paul', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL),
(8, 'Jean', 'syedsabir020@gmail.com', '2022-01-18 16:56:56', NULL, NULL, '2022-01-18 16:56:56', '2022-01-18 17:07:22', 1, '/OjDZ40RmwM01goZ7BxaQXuHmrBLslyERaEUDx8Li.jpg', '#2180f3', 0, 'hello  i am sabir', 'google', '117290773216317739510', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL),
(9, 'Hakam', 'happysngh309@yahoo.com', '2022-01-18 21:17:06', NULL, NULL, '2022-01-18 21:17:06', '2022-02-27 12:38:02', 0, 'users-avatar/m9BHVuanNhMz6jGrVR8WlVLnIxV2W383r0rmOSBV.png', '#2180f3', 0, NULL, 'facebook', '1012909346289957', 'Hakam', 'Singh', 'Malikpur, Haryana, India', 'Male', 'English', '2032-08-14', '8528343038', 0, 1, 'Hakam', '[\"india\"]', '[\"email\",\"last_name\",\"phone_number\",\"dob\",\"membershipnumber\"]', 'Hi \r\n\r\nI m Hakam Singh', '[\"Buisness\",\"Music\"]', 'Yes', 'Never', 'null', 1, NULL),
(10, 'Jean', 'jpi@socializus.net', '2022-01-18 22:04:40', NULL, NULL, '2022-01-18 22:04:40', '2022-02-26 23:01:58', 1, 'users-avatar/TDVhsmFl5JEPkOgG7in3rMXsLj6ldDHipgwynZMB.png', '#2180f3', 0, NULL, 'google', '107827744281088124322', 'Jean', 'B', 'Paris, France', 'Male', 'French', NULL, NULL, 0, 1, 'Jean', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL),
(11, 'Farhan', 'farhanzafar1643@gmail.com', '2022-01-20 17:04:58', '$2y$10$SHUmPWGOJcYxFWSBAncijeB2KW.IYJho3cnxNaucHSxjnx07Ah0eC', NULL, '2022-01-20 17:03:54', '2022-01-20 17:04:59', 1, 'avatar.png', '#2180f3', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL),
(12, 'Audreybile', 'billyleduc21@gmail.com', '2022-01-20 20:17:37', NULL, NULL, '2022-01-20 20:17:37', '2022-01-20 20:17:37', 1, 'avatar.png', '#2180f3', 0, NULL, 'google', '114492954632391483962', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL),
(13, 'b2p p4w', 'b2p@p4w.fr', '2022-01-23 15:03:46', NULL, NULL, '2022-01-23 15:03:46', '2022-02-27 19:23:08', 0, 'avatar.png', '#2180f3', 0, NULL, 'google', '116825172616568965365', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL),
(14, '-socializus app', 'app@socializus.net', '2022-01-23 15:21:59', NULL, NULL, '2022-01-23 15:21:59', '2022-01-23 15:21:59', 1, 'avatar.png', '#2180f3', 0, NULL, 'google', '101360876655990707629', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL),
(15, '-Socializus Website', 'socializus@gmail.com', '2022-01-23 15:22:37', NULL, NULL, '2022-01-23 15:22:37', '2022-01-23 15:22:37', 1, 'avatar.png', '#2180f3', 0, NULL, 'google', '101126478756791406113', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL),
(16, '-jpi', 'jpi.mobile@gmail.com', '2022-01-23 21:04:34', NULL, NULL, '2022-01-23 21:04:34', '2022-01-23 21:04:34', 1, 'avatar.png', '#2180f3', 0, NULL, 'google', '111328685813044262891', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL),
(17, 'Dan Bizet', 'danbizet@gmail.com', '2022-01-23 22:12:42', NULL, NULL, '2022-01-23 22:12:42', '2022-01-23 22:12:42', 1, 'avatar.png', '#2180f3', 0, NULL, 'google', '105926369347616894932', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL),
(18, 'babar lcd', 'babarlcd123@gmail.com', '2022-01-25 17:41:12', NULL, NULL, '2022-01-25 17:41:12', '2022-01-25 17:41:12', 1, 'avatar.png', '#2180f3', 0, NULL, 'google', '114750438566123939849', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL),
(19, 'Dominique Meyer', 'dominique_meyer@hotmail.com', '2022-02-03 14:47:07', NULL, NULL, '2022-02-03 14:47:07', '2022-02-03 14:48:18', 0, 'https://graph.facebook.com/v3.3/10158608477952322/picture?type=normal', '#2180f3', 0, NULL, 'facebook', '10158608477952322', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL),
(20, 'JohnJohn', 'designbyjhb@gmail.com', '2022-02-03 19:00:35', NULL, NULL, '2022-02-03 19:00:35', '2022-02-27 11:32:57', 1, 'https://lh3.googleusercontent.com/a/AATXAJzlPlpaMff2Cr3AgWoWoEv9zltPjAoW15Ql_eI2=s96-c', '#2180f3', 0, NULL, 'google', '116263334428883980550', 'john', 'john', 'Bordeaux, France', 'Female', 'French', NULL, NULL, 0, 1, 'JohnJohn', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL),
(21, 'Sanchez', 'samira.sanchez3654@gmail.com', '2022-02-04 20:31:26', NULL, NULL, '2022-02-04 20:31:26', '2022-02-04 20:34:40', 1, 'https://lh3.googleusercontent.com/a/AATXAJyqESkMvhRv8_4VXpzuhKp2HnbcM-lNBElpQ6L0=s96-c', '#2180f3', 0, NULL, 'google', '114816266353984432897', 'sanchez', 'sanchez', 'paris', 'Male', 'Bulgarian', '2012-02-01', NULL, 0, 1, 'sanchez', '[\"france\"]', '[\"email\",\"last_name\",\"phone_number\",\"dob\",\"membershipnumber\"]', NULL, '[\"Buisness\"]', 'Secret', 'Never', 'null', 0, NULL),
(22, 'chandan pathak', 'chandan009@yopmail.com', '2022-02-08 04:46:12', '$2y$10$6IJAA2k5aiK.miEgx9C1w.0b27qd1SJoUIf8rMOAE6OYGVC6X7kHq', NULL, '2022-02-08 04:44:21', '2022-02-08 04:49:55', 1, 'avatar.png', '#2180f3', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL),
(23, 'David', 'david009@yopmail.com', NULL, '$2y$10$YTb27UQcVsSrxLP1VxCJ2OGSZmeKIkvlzxEG1RojdI0rjAWIBhH3C', NULL, '2022-02-10 12:47:48', '2022-02-11 13:18:11', 0, 'avatar.png', '#2180f3', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL),
(24, 'Clever Boy', 'clever009@yopmail.com', '2022-02-10 12:49:26', '$2y$10$WzvZUD6kxoofBPRKlkuBxecJk9V/J5.MRLRczESfV/qekAPZxCmli', NULL, '2022-02-10 12:49:01', '2022-02-10 12:52:12', 0, 'avatar.png', '#2180f3', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL),
(25, 'Joe Root', 'joeroot009@yopmail.com', NULL, '$2y$10$OjKhT7FKhQ.3QtkF58Ew1OTURr5pcFPywJ0LudTeXeMknrPX8gi0y', NULL, '2022-02-10 13:04:33', '2022-02-10 13:16:23', 0, 'avatar.png', '#2180f3', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL),
(26, '', 'john009@yopmail.com', NULL, '$2y$10$LbkYym6FvMZ3bQzbs86q5.s.phQQpG9RI4zHjB0sLmYOd0JytZxFG', NULL, '2022-02-10 13:19:43', '2022-02-10 14:04:21', 0, 'avatar.png', '#2180f3', 0, NULL, NULL, NULL, 'John', NULL, NULL, NULL, NULL, NULL, NULL, 3, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL),
(27, 'joe', 'joe008@yopmail.com', NULL, '$2y$10$GEZdohgIb7I3wch8C4gsce.MDV/SxHy15Q7v8Ydz21OcME2tOmhRC', NULL, '2022-02-11 13:18:36', '2022-02-26 10:17:20', 1, 'users-avatar/g0pZPOBOVf3T9UteyOzajZFxfJC9JFlRlGnQtJ7v.jpg', '#2180f3', 0, NULL, NULL, NULL, 'joe', 'root', 'hhh', 'Male', 'Ukrainian', '2022-02-11', NULL, 3, 2, 'joe', '[\"hungary\",\"japan\",\"poland\",\"portugal\",\"romania\",\"47324560\",\"arableague\",\"china\",\"germany\"]', '[\"email\",\"last_name\",\"phone_number\",\"dob\",\"membershipnumber\"]', 'Hi I want to meet new people', '[\"Buisness\",\"Culture\",\"Party\",\"Sport\"]', 'Secret', 'Never', 'null', 1, NULL),
(28, 'Chandan', 'joee008@yopmail.com', NULL, '$2y$10$II8BXghR49G5TmkgLqvHdeI3ncs4jDev3gC5S1AY9yXdZcHES2N16', NULL, '2022-02-22 22:21:20', '2022-02-26 06:39:44', 0, 'avatar.png', '#2180f3', 0, NULL, NULL, NULL, 'Chandan', 'P', NULL, 'Female', 'French', NULL, NULL, 3, 1, 'Chandan', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL),
(29, 'John', 'david008@yopmail.com', NULL, '$2y$10$7PZtKsaYNBwjNHu1fM00UOzMQjaJEJ29tc/3zMNGcxjSwqMkzQfla', NULL, '2022-02-26 09:12:18', '2022-02-26 12:40:50', 1, 'users-avatar/dwXGA7jVy60wQ4wiJgWATkACgWcfWT8vpoIqWl0p.jpg', '#2180f3', 0, NULL, NULL, NULL, 'John', 'Blake', 'Paris, France', 'Male', 'French', NULL, NULL, 3, 2, 'John', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL),
(30, 'Laure', 'ricoricodavid27@gmail.com', '2022-02-26 19:56:40', NULL, NULL, '2022-02-26 19:56:40', '2022-02-26 19:57:45', 1, 'users-avatar/KgVLVD08rM83IYjSexMMbb7Za7femsFrKHtfJ5P6.jpg', '#2180f3', 0, NULL, 'google', '107118656533763622581', 'Laure', 'fgkjdhfg', 'Paris, France', 'Female', 'French', NULL, NULL, 0, 1, 'Laure', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL),
(31, 'DanBizet', 'danbizet@live.fr', '2022-02-27 10:56:59', NULL, NULL, '2022-02-27 10:56:59', '2022-02-27 11:06:30', 1, 'https://graph.facebook.com/v3.3/10221600668070228/picture?type=normal', '#2180f3', 0, NULL, 'facebook', '10221600668070228', 'Dan', 'Bizet', 'IVRY-SUR-SEINE', 'Male', 'French', '1977-07-11', '+33632537878', 0, 1, 'DanBizet', '[\"france\"]', '[\"email\",\"last_name\",\"phone_number\",\"dob\",\"membershipnumber\"]', NULL, '[\"Apero\",\"Buisness\",\"Culture\",\"Games\",\"Linguistic\",\"Meal\",\"Movies\",\"Music\",\"1\",\"Party\",\"Sport\",\"Travel\"]', 'Secret', 'Never', '\"Sometimes\"', 1, NULL),
(36, 'Hakam', 'mansukhsingh21@gmail.com', '2022-02-27 15:32:59', NULL, NULL, '2022-02-27 15:32:59', '2022-02-27 15:56:14', 0, 'users-avatar/e0oyNrOdUso4DkQoaIV7kly6foID34GSSAD0xvix.png', '#2180f3', 0, NULL, 'google', '116125991540215318261', 'Hakam', NULL, 'Pehowa, Haryana, India', 'Female', 'French', NULL, NULL, 0, 1, 'Hakam', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL),
(37, 'Ysa', 'sssylvestre02@gmail.com', '2022-02-27 15:37:32', NULL, NULL, '2022-02-27 15:37:32', '2022-02-27 15:39:02', 1, 'users-avatar/kDCi87XQ1SveNscMXxCcYOsoR9QytLPIt5gkYyUl.jpg', '#2180f3', 0, NULL, 'google', '116438760455613359260', 'Ysa', NULL, 'Paris, France', 'Female', 'French', NULL, NULL, 0, 1, 'Ysa', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL),
(38, 'Chandan Pathak', 'raghavpathak53@gmail.com', '2022-02-27 18:00:18', NULL, NULL, '2022-02-27 18:00:18', '2022-02-27 20:57:38', 1, 'https://lh3.googleusercontent.com/a/AATXAJyYcGfs4i7ZpuuO27QPdL1bWckbDsmR0Hq1xQdX=s96-c', '#2180f3', 0, NULL, 'google', '116704756897781514906', NULL, NULL, NULL, NULL, 'French', NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL),
(39, 'fddfsfds', 'a1p@p4w.fr', '2022-02-27 18:56:08', NULL, NULL, '2022-02-27 18:56:08', '2022-02-27 19:17:37', 1, 'https://lh3.googleusercontent.com/a-/AOh14GggmIF7meV2YQZgoLa-HNiaKZHSaBwdUeuv4lbX=s96-c', '#2180f3', 0, NULL, 'google', '102653726622358340443', 'fddfsfds', NULL, 'DFW International Airport (DFW), Aviation Drive, DFW Airport, Texas, États-Unis', 'Female', 'French', NULL, NULL, 0, 1, 'fddfsfds', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL),
(40, 'cecile', 'jackjackvon25@gmail.com', '2022-02-27 19:24:38', NULL, NULL, '2022-02-27 19:24:38', '2022-02-27 19:26:19', 1, 'users-avatar/dOcYZkjxQoNU89fcqNS2ar5dWgsI9o5OL8gibMgz.png', '#2180f3', 0, NULL, 'google', '113737400826676996361', 'cecile', 'hghgfghfhgf', 'Paris, France', 'Female', 'French', '2022-02-27', 'vbcvbc', 0, 1, 'cecile', 'null', '[\"email\",\"last_name\",\"phone_number\",\"dob\",\"membershipnumber\"]', NULL, NULL, NULL, NULL, NULL, 1, 17000),
(41, '', 'claudia.rakotou@gmail.com', NULL, '$2y$10$iygbP6eXbMfQ3crwV4P8A.2np4nQogbPuFwdALEiWZH27YpdnFqHK', NULL, '2022-02-27 19:28:59', '2022-02-27 19:28:59', 0, 'avatar.png', '#2180f3', 0, NULL, NULL, NULL, 'claudia', NULL, NULL, NULL, 'French', NULL, NULL, 3, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL),
(42, 'Paul', 'paulfgama@gmail.com', NULL, '$2y$10$qewsRWQ8POGAiMNW1OaSYOs4/gDM3UrXa7Rqj6XNWp52.IcqvY8oC', NULL, '2022-02-27 20:03:18', '2022-02-27 20:47:11', 0, 'users-avatar/KBbQgI8nt3pFedzG1Dn0KAtqhHJ2Xe1qek7on7YF.jpg', '#2180f3', 0, NULL, NULL, NULL, 'Paul', NULL, 'Paris, France', 'Male', 'French', NULL, NULL, 3, 1, 'Paul', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL),
(43, '-p4w', 'association@p4w.fr', '2022-02-27 23:00:02', NULL, NULL, '2022-02-27 23:00:02', '2022-02-27 23:00:02', 0, 'avatar.png', '#2180f3', 0, NULL, 'google', '109732550785890366846', NULL, NULL, NULL, NULL, 'French', NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `user_images`
--

CREATE TABLE `user_images` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `ch_favorites`
--
ALTER TABLE `ch_favorites`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `ch_messages`
--
ALTER TABLE `ch_messages`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `event_allowed_genders`
--
ALTER TABLE `event_allowed_genders`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `event_allowed_payment_methods`
--
ALTER TABLE `event_allowed_payment_methods`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `event_conditions`
--
ALTER TABLE `event_conditions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `event_conditions_organise_event_id_foreign` (`organise_event_id`);

--
-- Index pour la table `event_images`
--
ALTER TABLE `event_images`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `event_participents`
--
ALTER TABLE `event_participents`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Index pour la table `global_languages`
--
ALTER TABLE `global_languages`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `intrests`
--
ALTER TABLE `intrests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `intrests_user_id_foreign` (`user_id`);

--
-- Index pour la table `languages`
--
ALTER TABLE `languages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `languages_user_id_foreign` (`user_id`);

--
-- Index pour la table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `organise_events`
--
ALTER TABLE `organise_events`
  ADD PRIMARY KEY (`id`),
  ADD KEY `organise_events_user_id_foreign` (`user_id`),
  ADD KEY `organise_events_category_id_foreign` (`category_id`);

--
-- Index pour la table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Index pour la table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Index pour la table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Index pour la table `user_images`
--
ALTER TABLE `user_images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_images_user_id_foreign` (`user_id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT pour la table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT pour la table `event_allowed_genders`
--
ALTER TABLE `event_allowed_genders`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `event_allowed_payment_methods`
--
ALTER TABLE `event_allowed_payment_methods`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `event_conditions`
--
ALTER TABLE `event_conditions`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT pour la table `event_images`
--
ALTER TABLE `event_images`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT pour la table `event_participents`
--
ALTER TABLE `event_participents`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT pour la table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `global_languages`
--
ALTER TABLE `global_languages`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=183;

--
-- AUTO_INCREMENT pour la table `intrests`
--
ALTER TABLE `intrests`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `languages`
--
ALTER TABLE `languages`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=78;

--
-- AUTO_INCREMENT pour la table `organise_events`
--
ALTER TABLE `organise_events`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT pour la table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT pour la table `user_images`
--
ALTER TABLE `user_images`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `intrests`
--
ALTER TABLE `intrests`
  ADD CONSTRAINT `intrests_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `organise_events`
--
ALTER TABLE `organise_events`
  ADD CONSTRAINT `organise_events_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `organise_events_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
