// tabs


  $('ul.tabs li').click(function(){
    var $this = $(this);
    var $theTab = $(this).attr('id');
    if($this.hasClass('active')){
      // do nothing
    } else{
      $this.closest('.tabs_wrapper').find('ul.tabs li, .tabs_container .tab_content').removeClass('active');
      $('.tabs_container .tab_content[data-tab="'+$theTab+'"], ul.tabs li[id="'+$theTab+'"]').addClass('active');
    }
    
  });
  

// tabs

// next frame
jQuery(".next-frame").click(function(){
  jQuery(".frame-26").hide();
  jQuery(".frame-27").show();
  jQuery(".activity-slide").html("<p>2/3</p>");
})

jQuery(".frame-27 input").click(function(){
  jQuery(".frame-27").hide();
  jQuery(".frame-28").show();
  jQuery(".activity-slide").html("<p>3/3</p>");
})
// next frame

// frames 11-22-45
jQuery(".show-frame-11").click(function(){
  jQuery(".pagination li a").removeClass("active");
  jQuery(this).addClass("active");
  jQuery(".frame-22, .frame-45").hide();
  jQuery(".frame-11").show();
})

jQuery(".show-frame-22").click(function(){
  jQuery(".pagination li a").removeClass("active");
  jQuery(this).addClass("active");
  jQuery(".frame-11, .frame-45").hide();
  jQuery(".frame-22").show();
})

jQuery(".show-frame-45").click(function(){
  jQuery(".pagination li a").removeClass("active");
  jQuery(this).addClass("active");
  jQuery(".frame-11, .frame-22").hide();
  jQuery(".frame-45").show();
})
// frames 11-22-45

// menu toggle

jQuery(".menu-toggle").click(function () {
  jQuery("body").addClass("menu-open");
})

jQuery(".close-toggle").click(function () {
  jQuery("body").removeClass("menu-open");
})

// menu toggle

$('.tab-menu li a').on('click', function () {
  var target = $(this).attr('data-rel');
  $('.tab-menu li a').removeClass('active');
  $(this).addClass('active');
  $("#" + target).fadeIn('slow').siblings(".tab-box").hide();
  return false;
});
var $root = $('html, body');

$('a[href^="#app-main-body"]').click(function () {
  $root.animate({
    scrollTop: $($.attr(this, 'href')).offset().top
  }, 500);
  return false;
});


var today = new Date();
var minDate = today.setDate(today.getDate() + 1);

$('#datePicker').datetimepicker({
  useCurrent: false,
  format: "DD. MMM. YY",
  minDate: minDate
});

var firstOpen = true;
var time;

$('#timePicker').datetimepicker({
  useCurrent: false,
  format: "hh:mm A"
}).on('dp.show', function () {
  if (firstOpen) {
    time = moment().startOf('day');
    firstOpen = false;
  } else {
    time = "01:00 PM"
  }

  $(this).data('DateTimePicker').date(time);
});