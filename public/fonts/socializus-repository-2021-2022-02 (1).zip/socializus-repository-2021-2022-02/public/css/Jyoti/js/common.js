$('.tab-menu li a').on('click', function(){
    var target = $(this).attr('data-rel');
 $('.tab-menu li a').removeClass('active');
    $(this).addClass('active');
    $("#"+target).fadeIn('slow').siblings(".tab-box").hide();
    return false;
});
var $root = $('html, body');

$('a[href^="#app-main-body"]').click(function () {
    $root.animate({
        scrollTop: $( $.attr(this, 'href') ).offset().top
    }, 500);
    return false;
});


var today = new Date();
var minDate = today.setDate(today.getDate() + 1);

$('#datePicker').datetimepicker({
  useCurrent: false,
  format: "DD. MMM. YY",
  minDate: minDate
});

var firstOpen = true;
var time;

$('#timePicker').datetimepicker({
  useCurrent: false,
  format: "hh:mm A"
}).on('dp.show', function() {
  if(firstOpen) {
    time = moment().startOf('day');
    firstOpen = false;
  } else {
    time = "01:00 PM"
  }
  
  $(this).data('DateTimePicker').date(time);
});