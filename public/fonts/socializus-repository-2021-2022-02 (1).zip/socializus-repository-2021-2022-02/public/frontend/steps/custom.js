$("#frmInfo").addClass("disabledContent1");

function confirmRules(){
    $("#exampleModalCenter-confirmRules").modal('hide');
    $("#frmInfo").removeClass("disabledContent");
    $("#confirmRulBtn").hide();
    $(".modal-backdrop").remove();
}

// datepicker
$(".datepicker").datepicker({
    maxDate: new Date(),
    dateFormat: 'dd/mm/yy',
    onSelect: function() {
        return $("#frmInfo").valid();
    }
});

$(".datepicker2").datepicker({
    minDate: new Date(),
    dateFormat: 'dd/mm/yy',
    onSelect: function() {
        return $("#frmInfo").valid();
    }
});

// credit card
$('#credit-card').on('keypress change', function () {
  $(this).val(function (index, value) {
    return value.replace(/\W/gi, '').replace(/(.{4})/g, '$1 ');
  });
});

var sig = $('#sig').signature({syncField: '#signature64', syncFormat: 'PNG'});
$('#clear').click(function(e) {
    e.preventDefault();
    sig.signature('clear');
    $("#signature64").val('');
});

var sig2 = $('#sig2').signature({syncField: '#signature6464', syncFormat: 'PNG'});
$('#clear2').click(function(e) {
    e.preventDefault();
    sig2.signature('clear');
    $("#signature6464").val('');
});

// tooltip
$(document).ready(function() {
    $('[data-toggle="tooltip"]').tooltip();
});

// change payment method
function getPaymentMethod(id){
    if(id == 'Credit Card'){
        $('#ccPM').show();
    }else{
        $('#ccPM').hide();
    }
}