var frmInfo = $("#frmInfo");
var frmInfoValidator = frmInfo.validate({
  rules: {
    post_code: {
      required: true,
      number: true
    },
    email: {
      required: true,
      email: true
    },
    mobile: {
      required: true,
      number: true
    },
    tel_home: {
      required: true,
      number: true
    },
  }
});

var totalSteps = $("#totalSteps").html();
$("#demo").steps({
    forceMoveForward : true,
    enablePagination: false,
    onChange: function (currentIndex, newIndex, stepDirection) {
        // step1
        if (currentIndex === 0) {
            $(".step-footer").show();
            if (stepDirection === "forward") {
                $(".activity-slide").html('<p>2/'+totalSteps+'</p>');
                $("#ttile").html("Choose a topic");

                if (!$("#start_time").val()) {
                    alert("Please select start time");
                    return false;
                }

                if (!$("#timepickerDuration").val()) {
                    alert("Please select duration");
                    return false;
                }

                $("html, body").animate({ scrollTop: 0 }, "slow");

                $(".step-footer").hide();
                return frmInfo.valid();
            }
        }
        // step2
        if (currentIndex === 1) {

            if (stepDirection === "forward") {
                $(".step-footer").show();
                $("#ttile").html("Continue Creating an Activity");
                $(".activity-slide").html('<p>3/'+totalSteps+'</p>');
                if (!$("#category_id:checked").length) {
                    alert("Please select atleast one topic");
                    return false;
                }

                // test
                $("html, body").animate({ scrollTop: 0 }, "slow");
                return frmInfo.valid();
            }
            if (stepDirection === "backward") {
                $("#ttile").html("Choose a topic");
                $(".activity-slide").html('<p>1/'+totalSteps+'</p>');
                $("html, body").animate({ scrollTop: 0 }, "slow");
                $(".step-footer").hide();
                frmInfoValidator.resetForm();
            }
        }
        // step3
        if (currentIndex === 2) {
            if (stepDirection === "forward") {
   
                // if (!$('input[type=checkbox][name=dates]').is(':checked')) {
                //     alert("Please pick booking date and time");
                //     return false;
                // }
                
                $(".step-footer").show();
                $("html, body").animate({ scrollTop: 0 }, "slow");
                return frmInfo.valid();
            }
            if (stepDirection === "backward") {
                $(".step-footer").show();
                $("#ttile").html("Continue Creating an Activity");
                $(".activity-slide").html('<p>3/'+totalSteps+'</p>');
                $("html, body").animate({ scrollTop: 0 }, "slow");
               frmLoginValidator.resetForm();
            }
        }
        // step4
        if (currentIndex === 3) {
            if (stepDirection === "forward") {
   
                // if (!$('input[type=checkbox][name=dates]').is(':checked')) {
                //     alert("Please pick booking date and time");
                //     return false;
                // }
                
                $(".step-footer").show();
                $("html, body").animate({ scrollTop: 0 }, "slow");
                return frmInfo.valid();
            }
        }
        return true;
    },
    onFinish: function () {
        $("#frmInfo").submit();
    },
});

$('#radioBtn a').on('click', function () {
    var sel = $(this).data('title');
    var tog = $(this).data('toggle');
    $('#' + tog).prop('value', sel);

    $('a[data-toggle="' + tog + '"]').not('[data-title="' + sel + '"]').removeClass('active').addClass('notActive');
    $('a[data-toggle="' + tog + '"][data-title="' + sel + '"]').removeClass('notActive').addClass('active');
});

$(document).ready(function () {
    $(window).scroll(function () {
        if ($(this).scrollTop() > 100) {
            $('#scroll').fadeIn();
        } else {
            $('#scroll').fadeOut();
        }
    });
    $('#scroll').click(function () {
        $("html, body").animate({ scrollTop: 0 }, 600);
        return false;
    });
});

$(document).on('click', '.hide-off', function () {
    var value = $(this).attr('data-value');
    $('#'+$(this).attr('data-field')).val(1);
    $('.'+value+'-hide').hide();
    $(this).removeClass('hide-off');
    $(this).addClass('hide-on');
});

$(document).on('click', '.hide-on', function () {
    var value = $(this).attr('data-value');
    $('#'+$(this).attr('data-field')).val(0);
    $('.'+value+'-hide').show();
    $(this).removeClass('hide-on');
    $(this).addClass('hide-off');
    if($("#s11").html() == ''){
        $("#s11").mbSlider();
        $("#s12").mbSlider();
        $("#s13").mbSlider();
    }
});

function onPremiumFeature(id){
    if($('#' + id).is(":checked")){
        $("#btnCh").html('<a href="javascript:void(0);" type="button" class="green-comm-btn last-frame">Continue</a>');
    }else{
        $("#btnCh").html('<a href="javascript:void(0);" type="submit" class="green-comm-btn">Submit</a>');
    }
}