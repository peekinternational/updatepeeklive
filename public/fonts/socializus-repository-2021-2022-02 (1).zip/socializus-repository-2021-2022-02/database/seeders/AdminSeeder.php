<?php

namespace Database\Seeders;

use App\Models\Role;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Support\Str;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class AdminSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Role::create([
            'name' => 'Super Admin',
            'slug' => Str::slug('Super Admin'),
        ]);
        Role::create([
            'name' => 'Admin',
            'slug' => Str::slug('Admin'),
        ]);
        Role::create([
            'name' => 'Moderator',
            'slug' => Str::slug('moderator'),
        ]);
        User::create([
            'name'     => 'Socializus',
            'role'     => 1,
            'email'    => 'info@socializ.us',
            'password' => Hash::make('12345678'),
            'email_verified_at' => Carbon::now(),
        ]);
    }
}
