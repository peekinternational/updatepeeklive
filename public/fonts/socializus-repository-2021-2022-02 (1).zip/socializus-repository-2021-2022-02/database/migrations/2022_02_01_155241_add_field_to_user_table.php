<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddFieldToUserTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->integer('accountType')->default(1);
			$table->string('accountName')->nullable();
            $table->string('spoken_language')->nullable();
            $table->string('undertaking')->nullable();
            $table->string('aboutus')->nullable();
            $table->string('interest')->nullable();
 			$table->string('children')->nullable();
 			$table->string('tobacco')->nullable();
 			$table->string('alcohol')->nullable();


        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn('accountType');
            $table->dropColumn('accountName');
            $table->dropColumn('spoken_language');
            $table->dropColumn('undertaking');
			$table->dropColumn('aboutus');
            $table->dropColumn('interest');
 			$table->dropColumn('children');
 			$table->dropColumn('tobacco');
 			$table->dropColumn('alcohol');

        });
    }
}
