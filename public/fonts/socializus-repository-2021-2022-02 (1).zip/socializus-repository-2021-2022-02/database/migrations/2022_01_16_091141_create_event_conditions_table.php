<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateEventConditionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('event_conditions', function (Blueprint $table) {
            $table->id();
            $table->string('allowed_people')->nullable();
            $table->string('visible_phone')->nullable();
            $table->string('people_meeting')->nullable();
            $table->string('co_organizer')->nullable();
            $table->foreignId('organise_event_id')->constrained()->onDelete('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('event_conditions');
    }
}
