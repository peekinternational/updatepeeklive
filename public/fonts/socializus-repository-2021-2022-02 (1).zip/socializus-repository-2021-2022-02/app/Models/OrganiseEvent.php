<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OrganiseEvent extends Model
{
    use HasFactory;
	protected $dates = ['event_start_date'];
 	public $appends = [ 
        'time',
     ];
 	public function genders()
    {
        return $this->hasone(EventAllowedGender::class,'event_id','id');
    }
 	public function paymentMethods()
    {
        return $this->hasone(EventAllowedPaymentMethod::class,'event_id','id');
    }
	public function eventParticipent()
    {
        return $this->hasMany(EventParticipent::class,'event_id','id')->where('is_approved',1);
    }
	public function eventImages()
    {
        return $this->hasMany(EventImages::class,'event_id','id');
    }
	public function comments()
    {
        return $this->hasMany(Comment::class,'event_id','id')->where('reply_id',0);
    }
 	public function user()
    {
        return $this->belongsTo(User::class);
    }
    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    public function condition()
    {
        return $this->hasOne(EventCondition::class);
    }
	function getTimeAttribute()
	{
 		$date =  date('Y-m-d', strtotime($this->attributes['event_date']));
  		$time =  date('H:i:s', strtotime($this->attributes['event_start_time']));
  		return $date . ' ' . $time;
	}
}
