<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Support\Carbon;
class User extends Authenticatable implements MustVerifyEmail
{
    use HasApiTokens, HasFactory, Notifiable;
public $appends = [ 
        'age',
     ];

    /**
     * The attributes that are mass assignable.
     *
     * @var string[]
     */
    protected $fillable = [
        'name',
        'email',
        'provider',
        'email_verified_at',
        'provider_id',
        'active_status',
        'password',
		'avatar',
		'gender',
		'accountType',
		'accountName',
		'city',
		'dob',
		'phone_number',
		'role',
		'language',	
		'last_name',
		'first_name',
		'bio',
		'dark_mode',
		'messenger_color',
		'avatar',
		'active_status',
		'spoken_language',
		'undertaking',
		'aboutus',
		'interest',
		'children',
		'tobacco',
		'alcohol',
        'is_profile_updated'
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function events()
    {
        return $this->belongsTo(Event::class);
    }
public function getAgeAttribute()
{
	$date =  date('Y-m-d', strtotime($this->attributes['dob']));
    return Carbon::parse($date)->age;
}
}
