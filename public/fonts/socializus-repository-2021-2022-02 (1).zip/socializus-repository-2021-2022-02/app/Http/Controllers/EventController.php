<?php

namespace App\Http\Controllers;

use App\Models\{Category, Comment, OrganiseEvent,Event,EventAllowedGender,EventAllowedPaymentMethod, EventCondition, EventParticipent, EventImages , User};
use App\Http\Requests\StoreEventRequest;
use App\Http\Requests\UpdateEventRequest;
use Carbon\Carbon;
use Illuminate\Support\Str;
use Auth;
class EventController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $categories = Category::all();
        return view('events.create',compact('categories'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoreEventRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreEventRequest $request)
    {
        //dd($request->all());
		\DB::beginTransaction();
		$user = \Auth::user();
        $image= 'events/defaultevent.png';
		//
        $activityTitle = $request->activityTitle;

		$eventobj = new OrganiseEvent();
		$eventobj->user_id = $user->id;
		$eventobj->event_name = $request->event_name;
		$eventobj->category_id = $request->category_id;

        // Event Address
		$eventobj->address_type = $request->address_type;
        if($request->address_type == "address"){
            $eventobj->event_address = $request->address;
        }elseif($request->address_type == "online"){
            $eventobj->event_address = $request->google_meet_url;
        }else{
            $eventobj->event_address = $request->google_map_url;
        }

        // Event Date & Time
		$eventobj->event_date = ($request->date);
        $eventobj->event_start_time = $request->start_time;
        $eventobj->event_duration = $request->duration;
        $eventobj->event_end_time = $request->end_time;
		$eventobj->event_country = $request->event_country;
		$eventobj->event_pincode = $request->event_pincode;
		$eventobj->event_lat = $request->event_lat;
		$eventobj->event_lng = $request->event_lng;
		$eventobj->event_city = $request->event_city;
		$eventobj->event_state = $request->event_state;

        // Attendee Limitation
        $eventobj->unlimited_participants = $request->unlimited_participants;
        $eventobj->attendee_limitation = $request->attendee_limitation;

        // Price
        $eventobj->no_price = $request->no_price;
        $eventobj->price_type = $request->price_type;
        $eventobj->price = $request->price;

        // Restrictions
        $eventobj->manage_restrictions = $request->manage_restrictions;
        if($request->manage_restrictions == "0"){
            $eventobj->friends_with_me = $request->friends_with_me;
            $eventobj->allow_guest = $request->allow_guest;
            $eventobj->event_min_age = explode(',',$request->age_restriction)[0];
            $eventobj->event_max_age = explode(',',$request->age_restriction)[1];
        }

        // Third Page
        $eventobj->event_description = $request->event_description;
		$eventobj->find_us_description = $request->find_us_description;
        if($request->get('attributes')){
            $eventobj->attributes = implode(',',$request->get('attributes'));
        }
		$eventobj->image = $image;

        // premium
        if(env('PREMIUM_EMAIL') == Auth::user()->email){
            $eventobj->attendee_limitation_for_premium = $request->attendee_limitation_for_premium;
            $eventobj->repeat_event = $request->repeat_event;
            $eventobj->repeat_cycle = $request->repeat_cycle;
            $eventobj->repeat_day = $request->repeat_day;
            $eventobj->repeat_end_date = $request->repeat_end_date;
            $eventobj->partity_male = $request->partity_male;
            $eventobj->allow_people_co_organiser = $request->allow_people_co_organiser;
            $eventobj->info_line = $request->info_line;
            $eventobj->Buy_Tickets_Link = $request->Buy_Tickets_Link;
            $eventobj->other_social = $request->other_social;
            $eventobj->whatsapp_link = $request->whatsapp_link;
            $eventobj->facebook_link = $request->facebook_link;
            $eventobj->page_link = $request->page_link;
            $eventobj->meet_link = $request->meet_link;
            $eventobj->telegram_link = $request->telegram_link;
            $eventobj->manage_parity = $request->manage_parity;
        }


		$eventobj->save();

        $allowed = new EventCondition();
        $allowed->allowed_people= 0;
        $allowed->organise_event_id = $eventobj->id;
        $allowed->visible_phone = 0;
        $allowed->people_meeting = 0;
        $allowed->co_organizer = 0;
        $allowed->save();

        // add event participant
        $atendee = new EventParticipent();
        $atendee->event_id = $eventobj->id;
        $atendee->user_id = $user->id;
        $atendee->is_approved=1;
        $atendee->is_organiser=1;
        $atendee->is_organiser_approved=1;
        if($request->manage_restrictions == "0"){
            $atendee->friend_count = ($request->friends_with_me+1);
        }
        $atendee->save();

        // add event images

        if(isset($request->file)){
            foreach($request->file as $file){
                
                $propertyThumbnailDirectory = 'public/events';
                if (!\Storage::exists($propertyThumbnailDirectory))
                {
                    \Storage::makeDirectory($propertyThumbnailDirectory);
                }
                $thumbnailUrl = \Storage::putFile($propertyThumbnailDirectory, $file);

                $image = $thumbnailUrl;
                $image = str_replace(array("public/"), "", $image);

                $eve_images = new EventImages();
                $eve_images->event_id = $eventobj->id;
                $eve_images->image = $image;
                $eve_images->save();
            }
        }

		\DB::commit();
		return redirect()->route('home')->with('success', 'Request Successfull');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Event  $event
     * @return \Illuminate\Http\Response
     */
    public function show(Event $event)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Event  $event
     * @return \Illuminate\Http\Response
     */
    public function edit(OrganiseEvent $event,$id)
    {
        $event = OrganiseEvent::with('condition')->findOrFail($id);
        $categories = Category::all();
		$from = $event->event_start_date;
		$to = $event->event_end_date;
		$event->diff_in_hours = $from->diffInHours($to);
		// dd($event);
		 return view('events.edit',compact('event','categories'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdateEventRequest  $request
     * @param  \App\Models\Event  $event
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateEventRequest $request,$id)
    {


		\DB::beginTransaction();
		$user = \Auth::user();
        $eventobj = OrganiseEvent::findOrFail($id);
    //    dd($eventobj);
		//
        $event_type = $request->event_type;
        // $event_type = isset($request->event_country) ? 0 : (isset($request->event_url) ? 2 : 1);
		// $payment_type = isset($request->payable_amount) ? 1:0;
		if ($request->hasFile('image'))
		{
			$propertyThumbnailDirectory = 'public/events';
			if (!\Storage::exists($propertyThumbnailDirectory))
			{
				\Storage::makeDirectory($propertyThumbnailDirectory);
			}
			$thumbnailUrl = \Storage::putFile($propertyThumbnailDirectory, $request->file('image'));

			$image = $thumbnailUrl;
		$image = str_replace(array("public/"), "", $image);
		}

        $image =isset($image) ? $image : $eventobj->image;

		$eventobj->user_id = $user->id;
        $eventobj->category_id = $request->category_id;
		$eventobj->event_name = isset($request->event_name) ? $request->event_name : $eventobj->event_name;
		$eventobj->event_type = $event_type;
        $eventobj->event_phone = $request->event_phone;
        $eventobj->event_time =$request->event_time;
		$eventobj->event_address = $request->event_address;
		$eventobj->event_country = $request->event_country;
		$eventobj->event_pincode = $request->event_pincode;
		$eventobj->event_lat = $request->event_lat;
		$eventobj->event_lng = $request->event_lng;
		$eventobj->event_city = $request->event_city;
		$eventobj->event_state = $request->event_state;
		$eventobj->event_start_date = isset($request->event_start_date) ? $request->event_start_date : $eventobj->event_start_date;
		$eventobj->image = $image;
        $eventobj->duration= $request->duration;
		$eventobj->event_description = $request->event_description;
		$eventobj->find_us_description = $request->find_us_description;
		$eventobj->payment_type = $request->payment_type;
		$eventobj->event_amount = $request->event_amount;
		$eventobj->no_of_participent = $request->no_of_participent;
		$eventobj->event_min_age = $request->event_min_age;
		$eventobj->event_max_age = $request->event_max_age;
        $eventobj->event_url = $request->event_url;

		$eventobj->save();

        $allowed = EventCondition::where('organise_event_id',$id)->first();
        $allowed->allowed_people= $request->allowed_people;
        $allowed->organise_event_id = $eventobj->id;
        $allowed->visible_phone = $request->visible_phone;
        $allowed->people_meeting = $request->people_meeting;
        $allowed->co_organizer = $request->co_organizer;
        $allowed->save();


		\DB::commit();
		return redirect()->route('home')->with('success', 'Request Successfull');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Event  $event
     * @return \Illuminate\Http\Response
     */
    public function destroy(Event $event)
    {
        //
    }
    public function detail($id)
    {
        $event = OrganiseEvent::with('eventImages','user','eventParticipent')->findOrFail($id);
		$participent = EventParticipent::where('event_id',$id)->where('user_id',Auth::user()->id)->where('is_blacklisted',0)->count();
		// no of Participent 
        $event->not_a_participent = $participent;
		$event_organiser = EventParticipent::where('event_id',$id)->where('is_organiser',1)->where('is_organiser_approved',1)->where('is_blacklisted',0)->get();
        
		$event_organiser_waiting = EventParticipent::where('event_id',$id)->where('is_organiser',1)->where('user_id','!=',$event->user_id)->where('is_blacklisted',0)->get();

        $event_member_waiting = EventParticipent::where('event_id',$id)->where('is_approved',0)->where('is_blacklisted',0)->get();

        $event_member_bl = EventParticipent::where('event_id',$id)->where('is_blacklisted',1)->get();

		$is_organiser = EventParticipent::where('event_id',$id)->where('user_id',Auth::user()->id)->where('is_organiser',1)->where('is_blacklisted',0)->first();

        $comments = Comment::where('event_id',$event->id)->get();
        $no_of_participent = EventParticipent::where('event_id',$id)->where('is_blacklisted',0)->where('is_approved',1)->count();
        $approved_particpents_count = EventParticipent::where('is_approved',1)->where('is_blacklisted',0)->where('event_id',$event->id)->count();
        $waiting_participents_count = EventParticipent::where('is_approved',0)->where('is_blacklisted',0)->where('event_id',$event->id)->count();
		$average_age_all_participent = EventParticipent::where('event_id',$id)->pluck('user_id');
		$average_age = averageAgeCount($average_age_all_participent);

	    $approved_particpents = EventParticipent::where('is_approved',1)->where('is_blacklisted',0)->where('event_id',$event->id)->paginate(8);
        $waiting_participents = EventParticipent::where('is_approved',0)->where('is_blacklisted',0)->where('event_id',$event->id)->paginate(10);

        $pCount = 0;
        if(count($event->eventParticipent)){
            for($i=0;$i<count($event->eventParticipent);$i++){
                $event->eventParticipent[$i]->userDetails = User::where('id',$event->eventParticipent[$i]->user_id)->first();
                $pCount += $event->eventParticipent[$i]->friend_count;
            }
        }

        $event->pCount = $pCount;

        if(count($comments)){
            for($i=0;$i<count($comments);$i++){
                $comments[$i]->userDetails = User::where('id',$comments[$i]->user_id)->first();
            }
        }

        if(count($event_organiser)){
            for($i=0;$i<count($event_organiser);$i++){
                $event_organiser[$i]->userDetails = User::where('id',$event_organiser[$i]->user_id)->first();
            }
        }

        if(count($event_organiser_waiting)){
            for($i=0;$i<count($event_organiser_waiting);$i++){
                $event_organiser_waiting[$i]->userDetails = User::where('id',$event_organiser_waiting[$i]->user_id)->first();
            }
        }

        if(count($event_member_waiting)){
            for($i=0;$i<count($event_member_waiting);$i++){
                $event_member_waiting[$i]->userDetails = User::where('id',$event_member_waiting[$i]->user_id)->first();
            }
        }

        if(count($event_member_bl)){
            for($i=0;$i<count($event_member_bl);$i++){
                $event_member_bl[$i]->userDetails = User::where('id',$event_member_bl[$i]->user_id)->first();
            }
        }

		return view('events.single', compact('waiting_participents','approved_particpents','event','comments','no_of_participent','average_age','approved_particpents_count','waiting_participents_count','event_organiser','is_organiser','event_organiser_waiting','event_member_waiting','event_member_bl'));
    }

    public function kickout($id)
    {
        EventParticipent::where('user_id',$id)->delete();
        return back();
    }

    public function delete($id)
    {
        $del = OrganiseEvent::findOrFail($id);

        $del->delete();
        return redirect()->route('home');
    }
    public function getalldata($id = null)
    {
        $events = EventParticipent::where('event_id', $id)->get();

        $filterdata = view('ajax.event-filter')->with('events', $events)->render();
        return response()->json($filterdata);
    }

    public function readAll($id)
    {
        $event = OrganiseEvent::find($id);
        $event_desc = $event->event_description;
        $alldata = view('ajax.readall')->with('event_desc', $event_desc)->render();
        return response()->json($alldata);
    }

    public function pastEvents()
    {
        $events = OrganiseEvent::with('category','condition','genders','paymentMethods','eventParticipent')
        ->where('event_date', '<',date('m/d/Y'))
        ->orderBy('event_start_date','ASC')
        ->orderBy('event_time','ASC')->get();
        //dd($events);

        if(count($events)){
            for($i=0;$i<count($events);$i++){
                $events[$i]->pCount = 0;
                foreach($events[$i]->eventParticipent as $eve){
                    $events[$i]->pCount += $eve->friend_count;
                }
            }
        }

        $today_events = OrganiseEvent::whereDate('event_date','<', date('m/d/Y'))->get()->groupBy(function($item){ return $item->created_at->format('l d F , y'); });
        return view('events.past',get_defined_vars());
    }

    public function myEvents()
    {
        // get event id from event participant
        $eventsP = EventParticipent::where('user_id', Auth::user()->id)->pluck('event_id');
        $mine_upcoming_events = OrganiseEvent::with('category','condition','genders','paymentMethods','eventParticipent')
        ->whereIn('id', $eventsP)
        ->where('event_date', '>',date('m/d/Y'))
        ->orderBy('event_start_date','ASC')
        ->orderBy('event_time','ASC')->get();

        if(count($mine_upcoming_events)){
            for($i=0;$i<count($mine_upcoming_events);$i++){
                $mine_upcoming_events[$i]->pCount = 0;
                foreach($mine_upcoming_events[$i]->eventParticipent as $eve){
                    $mine_upcoming_events[$i]->pCount += $eve->friend_count;
                }
            }
        }
        
        $mine_past_events = OrganiseEvent::with('category','condition','genders','paymentMethods','eventParticipent')
        ->whereIn('id', $eventsP)
        ->where('event_date', '<',date('m/d/Y'))
        ->orderBy('event_start_date','ASC')
        ->orderBy('event_time','ASC')->get();

        $mine_events = OrganiseEvent::with('category','condition','genders','paymentMethods','eventParticipent')
        ->where('user_id', Auth::user()->id)
        ->orderBy('event_start_date','ASC')
        ->orderBy('event_time','ASC')->get();
        //dd($events);
       return view('events.mine',compact('mine_upcoming_events','mine_past_events','mine_events'));
    }
}
