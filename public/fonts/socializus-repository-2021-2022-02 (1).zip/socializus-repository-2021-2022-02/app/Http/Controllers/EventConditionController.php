<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class EventConditionController extends Controller
{
    //
}
