<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use App\Models\User;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }

    protected function redirectTo()
    {
        if (auth()->user()->is_profile_updated > 1) {
            return '/home';
        }
        return '/profile/'.auth()->user()->id;
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'first_name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return \App\Models\User
     */
    protected function create(array $data)
    {

        // $validation = Validator::make($request->all(),[
        //     'email' => 'required|unique:users',
        //     'name' => 'required',
        //     'password' => 'required',
        // ]);
        // $error_array = array();
        // $success_output = '';
        // if ($validation->fails()){
        //     foreach($validation->messages()->getMessages() as $field_name => $messages){
        //         $error_array[] = $messages;
        //     }
        // }else{
            // if (request()->hasFile('avatar'))
            // {
            // 	$propertyThumbnailDirectory = 'public/users-avatar';
            // 	if (!\Storage::exists($propertyThumbnailDirectory))
            // 	{
            // 		\Storage::makeDirectory($propertyThumbnailDirectory);
            // 	}
            // 	$thumbnailUrl = \Storage::putFile($propertyThumbnailDirectory, request()->file('avatar'));
            // 	$avatar = str_replace(array("public/"), "", $thumbnailUrl);	
            // }

            $last_membership_number = User::orderBy('membership_number','desc')->first();

            return User::create([
                'first_name' => $data['first_name'],
                'membership_number' => $last_membership_number->membership_number+1,
                'role' => 3,
                'email' => $data['email'],
                'password' => Hash::make($data['password']),
            ]);
        //}
    }
}
