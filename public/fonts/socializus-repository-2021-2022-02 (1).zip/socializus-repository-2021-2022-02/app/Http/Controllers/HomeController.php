<?php

namespace App\Http\Controllers;

use App\Models\Event;
use App\Models\OrganiseEvent;
use App\Models\GlobalLanguages;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Password;
use Mapper;
use Mail;
use Illuminate\Support\Str;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        // $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $user = Auth::user();
        if($user){
            if($user->active_status==0)
            {
                $user->active_status=1;
                $user->save();
            }
        }	
        $events = OrganiseEvent::with('category','condition','genders','paymentMethods','eventParticipent')->where('event_date', '>',date('m/d/Y'))->get()->where('time','>',Carbon::now()->subHours(config('constant.EVENT_EXPIRED_BEOFRE_HOUR'))->format('Y-m-d H:i:s'))->sortBy('time');

        if(count($events)){
            for($i=0;$i<count($events);$i++){
                $events[$i]->userDetails = User::where('id',$events[$i]->user_id)->first();

                $events[$i]->pCount = 0;
                foreach($events[$i]->eventParticipent as $eve){
                    $events[$i]->pCount += $eve->friend_count;
                }
            }
        }

        //dd($events);

        //$events = OrganiseEvent::with('eventImages','category','condition','genders','paymentMethods','eventParticipent')->get();
        //dd($events);
        $today_events = OrganiseEvent::whereDate('created_at','>=', Carbon::today())->get()->groupBy(function($item){ return $item->created_at->format('l d F , y'); });
        return view('home',compact('events','today_events'));
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function mapActivites()
    {
        $user = Auth::user();
        if($user){
            if($user->active_status==0)
            {
                $user->active_status=1;
                $user->save();
            }
        }
        return view('map_activities');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function notifications()
    {
        $user = Auth::user();
        if($user){
            if($user->active_status==0)
            {
                $user->active_status=1;
                $user->save();
            }
        }
        return view('notifications');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function members()
    {
        $user = Auth::user();
        if($user){
            if($user->active_status==0)
            {
                $user->active_status=1;
                $user->save();
            }
        }
        return view('members');
    }

    public function forgotPassword()
    {
        return view('auth.forgotPassword');
    }

    public function forgotPasswordProcess(Request $request){

        $user = DB::table('users')->where('email', $request->email)->select('id')->first();
        if($user){

            //Create Password Reset Token
            DB::table('password_resets')->insert([
                'email' => $request->email,
                'token' => str_random(60),
                'created_at' => Carbon::now()
            ]);

            //Get the token just created above
            $tokenData = DB::table('password_resets')
            ->where('email', $request->email)->first();

            if ($this->sendResetEmail($request->email, $tokenData->token)) {
                return redirect()->back()->with('success', 'A reset link has been sent to your email address.');
            } else {
                return redirect()->back()->withErrors(['error', 'A Network Error occurred. Please try again.']);
            }
        }else{
            return redirect()->back()->withErrors(['error' => 'Email is not registered with us!']);
        }
    }

    private function sendResetEmail($email, $token)
    {
        //Retrieve the user from the database
        $user = DB::table('users')->where('email', $email)->select('first_name', 'email')->first();
        //Generate, the password reset link. The token generated is embedded in the link
        $link = config('base_url') . 'password/reset/' . $token . '?email=' . urlencode($user->email);

        try {
            Mail::send('auth.passwords.email', ['token' => $token, 'link' => $link], function($message) use($email){
                $message->to($email);
                $message->subject('Reset Password');
            });
            return true;
        } catch (\Exception $e) {
            return false;
        }
    }

    public function profile($id , $redirection_page = "Form_one")
    {
        $last_membership_number = User::orderBy('membership_number','desc')->first();
        $user = User::where('id',$id)->first();
        $GlobalLanguages = GlobalLanguages::all();
		$user->redirect_form = $redirection_page;
        return view('profile.profile',compact('user','GlobalLanguages'));
    }

	public function profileupdateSecond(Request $request)
	{
	    $user = User::where('id',$request->userId)->first();
		$user->phone_number = $request->phone_number;
		$user->last_name = $request->last_name;
		$user->dob = Carbon::parse($request->dob)->format('Y-m-d');
		$user->spoken_language = json_encode($request->spoken_language);
		$user->email = $request->email;
		$user->undertaking = json_encode($request->undertaking);
		$user->save();
        $user = User::where('id',$request->userId)->first();
		$user->redirect_form = "Form_three";

        if($request->submit == "continue"){
            return redirect()->route('profile',[$user->id,"Form_three"]);
        }else{
            return redirect()->route('home');
        }
	}

	public function profileupdateThird(Request $request)
	{
	  	$user = User::where('id',$request->userId)->first();
		$user->aboutus = $request->aboutus;
		$user->interest = $request->interest;
		$user->children = $request->children;
		$user->tobacco = $request->tobacco;
		$user->alcohol = json_encode($request->alcohol);
		$user->save();
        $user = User::where('id',$request->userId)->first();
        return redirect()->route('home');
	}

 	public function profileSave(Request $request)
    {

        //dd($request->all());
        $image = "avatar.png";
        if ($request->hasFile('avatar'))
		{
			$propertyThumbnailDirectory = 'public/users-avatar';
			if (!\Storage::exists($propertyThumbnailDirectory))
			{
				\Storage::makeDirectory($propertyThumbnailDirectory);
			}
			$thumbnailUrl = \Storage::putFile($propertyThumbnailDirectory, $request->file('avatar'));

			$image = $thumbnailUrl;
		    $image = str_replace(array("public/"), "", $image);
		}

        $user = User::where('id',$request->userId)->first();
		$user->gender = ($request->gender == 1) ? "Male" : "Female";
		$user->first_name = $request->first_name;
		$user->name = $request->name;
		$user->city = $request->city;
		$user->language = $request->language;
		$user->accountType = $request->accountType;
		$user->accountName = $request->name;
        if ($request->hasFile('avatar')){
		$user->avatar = $image;
        }
		$user->is_profile_updated = 1;
		$user->save();
        $user = User::where('id',$request->userId)->first();
		$user->redirect_form = "Form_two";

        if($request->submit == "continue"){
            return redirect()->route('profile',[$user->id,"Form_two"]);
        }else{
            return redirect()->route('home');
        }
    }

    public function general(Request $req)
    {
        $user = Auth::user();
        $req->validate([
            'email' => 'required|email',
            'name' => 'required',

        ]);

        $user->name = $req->name;
        $user->email = $req->email;
        $user->bio = $req->bio;
        if ($req->hasFile('photo'))
		{
			$propertyThumbnailDirectory = 'public/users-avatar';
			if (!\Storage::exists($propertyThumbnailDirectory))
			{
				\Storage::makeDirectory($propertyThumbnailDirectory);
			}
			$thumbnailUrl = \Storage::putFile($propertyThumbnailDirectory, $req->file('photo'));

			$image = $thumbnailUrl;
			$image = str_replace(array("public/users-avatar"), "", $image);
		}

        $image =isset($image) ? $image : 'avatar.png';
        $user->avatar = $image;
        $user->save();
        return redirect()->back()->with('success', 'Profile updated successfully');
    }

    public function password(Request $req)
    {
        $user = Auth::user();
        $req->validate([
            'current_password' => 'required|password',
            'password' => 'required|min:8',
            'confirm_password' => 'required|same:password'
        ]);
        $user->password = bcrypt($req->password);
        $user->save();

        return redirect()->back()->with('success', 'Password updated Successfully!');
    }

    public function userProfile($id)
    {
        $user = User::findOrFail($id);
        return view('profile.user_profile',compact('user'));
    }

    public function map()
    {
        Mapper::map(30.181459, 71.492157);
	    return view('map');
    }
}
