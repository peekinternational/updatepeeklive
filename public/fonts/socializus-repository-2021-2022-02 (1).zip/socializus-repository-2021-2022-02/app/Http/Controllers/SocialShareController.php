<?php

namespace App\Http\Controllers;

use App\Models\OrganiseEvent;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class SocialShareController extends Controller
{
    public function index($id)
    {
        $shareButtons = \Share::page(
            route('event.detail',$id),
            'Hey There!  i am inviting you to my
             beatiful event that i am hosting at Socializus, Please come and join me
             we will have greate fun togehter....',
        )
        ->facebook()
        ->twitter()
        ->linkedin()
        ->telegram()
        ->whatsapp()
        ->reddit();

        $event = OrganiseEvent::findOrFail($id);

        return view('events.invite', compact('shareButtons', 'event'));
    }
}
