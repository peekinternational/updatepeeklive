<?php

namespace App\Http\Controllers;

use App\Models\EventParticipent;
use Illuminate\Http\Request;
// Constants
use App\Constants\ResponseCode;
use App\Constants\Message;
use App\Models\EventCondition;
use App\Models\OrganiseEvent;
use Egulias\EmailValidator\Exception\UnclosedComment;
use Illuminate\Support\Facades\Auth;

class EventParticipentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
  public function index(Request $request , $id)
    {
        try
        {
            $eventParticipent = EventParticipent::where('event_id',$id)->with('event.user')->get();
            $response = makeResponse(ResponseCode::SUCCESS, Message::REQUEST_SUCCESSFUL, true, null, $eventParticipent);
        }
        catch (\Exception $e)
        {
            $response = makeResponse(ResponseCode::FAIL, $e->getMessage(), false);
        }
        return $response;
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
     public function store(Request $request)
    {
        $check_condition= OrganiseEvent::where('id',$request->event_id)->with('condition')->first();

        $validator = validateData($request,'ADD_EVENT_PARTICIPENT');
        if ($validator['status'])
            return makeResponse(ResponseCode::FAIL,$validator['errors']->first(),false,$validator['errors']);

        \DB::beginTransaction();
        try
        {
            $user = \Auth::user();
            if(EventParticipent::where('event_id',$request->event_id)->where('is_approved',0)->count()>10){
             return back()->with('sucess','done');
            }

            if($check_condition->unlimited_participants == 1){
                $is_approved = 1;
            }else{

                $check_joined = EventParticipent::where('event_id',$request->event_id)->where('is_approved',1)->count();
                if($check_condition->attendee_limitation > $check_joined){
                    $is_approved = 1;
                }else{
                    $is_approved = 0;
                }
            }

            $eventParticipent =  EventParticipent::create([
                                "event_id"    => $request->event_id,
                                "user_id"     => $user->id ?? '',
                                'is_approved' => $is_approved,

            ]);
            \DB::commit();
            $response = makeResponse(ResponseCode::SUCCESS, "user Participated", true, null, $eventParticipent);
        }
        catch (\Exception $e)
        {
            \DB::rollBack();
            $response = makeResponse(ResponseCode::FAIL, $e->getMessage(), false);
        }
        return $response;
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
     public function storeOrganiser(Request $request)
    {
        $check_condition= OrganiseEvent::where('id',$request->event_id)->with('condition')->first();

        $validator = validateData($request,'ADD_EVENT_ORGANISER');
        if ($validator['status'])
            return makeResponse(ResponseCode::FAIL,$validator['errors']->first(),false,$validator['errors']);

        \DB::beginTransaction();
        try
        {
            $user = \Auth::user();
            if(EventParticipent::where('event_id',$request->event_id)->where('is_approved',0)->count()>10){
             return back()->with('sucess','done');
            }

            // check if already organiser
            $check = EventParticipent::where('event_id',$request->event_id)->where('user_id',$user->id)->first();
            if(!$check){
                $eventParticipent =  EventParticipent::create([
                                    "event_id"    => $request->event_id,
                                    "user_id"     => $user->id ?? '',
                                    'is_approved' => EventCondition::whereNotNull('co_organiser')?1:0,
                                    'is_organiser' => 1,

                ]);
            }else{
                $eventParticipent =  EventParticipent::where('event_id',$request->event_id)->where('user_id',$user->id)->update(['is_organiser'=>1]);
            }
            \DB::commit();
            $response = makeResponse(ResponseCode::SUCCESS, "user Participated", true, null, $eventParticipent);
        }
        catch (\Exception $e)
        {
            \DB::rollBack();
            $response = makeResponse(ResponseCode::FAIL, $e->getMessage(), false);
        }
        return $response;
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
     public function organiserRequestAction(Request $request)
    {
        $check_condition = OrganiseEvent::where('id',$request->event_id)->with('condition')->first();

        $validator = validateData($request,'ADD_EVENT_ORGANISER');
        if ($validator['status'])
            return makeResponse(ResponseCode::FAIL,$validator['errors']->first(),false,$validator['errors']);

        \DB::beginTransaction();
        try
        {
            $user = \Auth::user();

            if($request->type == "o"){
                if($request->status == 1){
                    $arr = array('is_organiser_approved'=>1);
                }else{
                    $arr = array('is_organiser'=>0,'is_organiser_approved'=>0);
                }
            }else{
                if($request->status == 1){
                    $arr = array('is_approved'=>1);
                }else{
                    $arr = array('is_blacklisted'=>1,'is_approved'=>0,'is_organiser_approved'=>0,'is_organiser'=>0);
                }
            }

            $eventParticipent =  EventParticipent::where('event_id',$request->event_id)->where('user_id',$request->user_id)->update($arr);

            if($request->status == 1){ // update event attendee count
                $arr = array('is_approved'=>1);
                OrganiseEvent::where('id',$request->event_id)->with('condition')->update(['attendee_limitation'=>($check_condition->attendee_limitation + 1)]);
            }

            \DB::commit();
            $response = makeResponse(ResponseCode::SUCCESS, "action performed", true, null, $eventParticipent);
        }
        catch (\Exception $e)
        {
            \DB::rollBack();
            $response = makeResponse(ResponseCode::FAIL, $e->getMessage(), false);
        }
        return $response;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Comment  $comment
     * @return \Illuminate\Http\Response
     */
     public function removeBlacklisted(Request $request)
    {  
        $validator = validateData($request,'ADD_EVENT_ORGANISER');
        if ($validator['status'])
            return makeResponse(ResponseCode::FAIL,$validator['errors']->first(),false,$validator['errors']);
        
        \DB::beginTransaction();
        try 
        {
            $id      =   $request->id;
            $rBl     =   EventParticipent::find($id);
            
            if(empty($rBl))
                return $response = makeResponse(ResponseCode::FAIL,Message::RECORD_NOT_FOUND,false,null);  
            
            $rBl->delete();
            \DB::commit();
            $response = makeResponse(ResponseCode::SUCCESS, "Removed Successfully.", true);
        }
        catch (\Exception $e) 
        {
            \DB::rollBack();
            $response = makeResponse(ResponseCode::FAIL, $e->getMessage(), false);
        }
        return $response;
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\EventParticipent  $eventParticipent
     * @return \Illuminate\Http\Response
     */
    public function show(EventParticipent $eventParticipent)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\EventParticipent  $eventParticipent
     * @return \Illuminate\Http\Response
     */
    public function edit(EventParticipent $eventParticipent)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\EventParticipent  $eventParticipent
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, EventParticipent $eventParticipent)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\EventParticipent  $eventParticipent
     * @return \Illuminate\Http\Response
     */
    public function delete(Request $request)
    {
        $validator = validateData($request,'ADD_EVENT_PARTICIPENT');
        if ($validator['status'])
            return makeResponse(ResponseCode::FAIL,$validator['errors']->first(),false,$validator['errors']);

        \DB::beginTransaction();
        try
        {
            $user = \Auth::user();
            $eventParticipent =  EventParticipent::where('event_id',$request->target_event_id)
                                                  ->where('user_id',Auth::id())->delete();

            \DB::commit();
            $response = makeResponse(ResponseCode::SUCCESS, "user Unsubscribed", true, null, $eventParticipent);
        }
        catch (\Exception $e)
        {
            \DB::rollBack();
            $response = makeResponse(ResponseCode::FAIL, $e->getMessage(), false);
        }
        return $response;
    }

    public function approve($id)
    {
        $status = EventParticipent::findOrFail($id);
        $status->is_approved = 1;
        $status->save();

        return back();
    }

    public function kickout($id)
    {
        $user = EventParticipent::findOrFail($id);
        $user->delete();
        return back();
    }
}
