<?php

namespace App\Http\Controllers;

use App\Models\User;
use Carbon\Carbon;
use Socialite;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;

class SocialLoginController extends Controller
{
    public function redirect($provider)
    {
        return Socialite::driver($provider)->redirect();
    }
    public function Callback(Request $request ,$provider)
    {
        $userSocial     =   Socialite::driver($provider)->stateless()->user();
        $users          =   User::where(['email' => $userSocial->getEmail()])->first();
        $last_membership_number = User::orderBy('membership_number','desc')->first();
        if ($users) {
            Auth::login($users);
            if ($users->is_profile_updated > 0) {
                return redirect()->route('home');
            }
            return Redirect::to('profile/'.$users->id);
        } else {
            $user = User::create([
                'name'          => $userSocial->getName(),
                'email'         => $userSocial->getEmail(),
                'membership_number' => $last_membership_number->membership_number+1,
                'email_verified_at' => Carbon::now(),
                'avatar'         => 'avatar.png',
                'provider_id'   => $userSocial->getId(),
                'provider'      => $provider,
            ]);
            Auth::login($user);
            if ($user->is_profile_updated > 0) {
                return redirect()->route('home');
            }
            return Redirect::to('profile/'.$user->id);
        }
    }
}
