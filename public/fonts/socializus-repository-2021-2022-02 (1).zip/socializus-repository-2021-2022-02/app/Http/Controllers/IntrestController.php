<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class IntrestController extends Controller
{
    //
}
